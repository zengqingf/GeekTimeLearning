package com.Company.SDKFramework;

import com.google.gson.Gson;
import com.unity3d.player.*;

import android.R.string;
import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

public class UnityPlayerActivity extends Activity {
	protected UnityPlayer mUnityPlayer; // don't change the name of this
										// variable; referenced from native code

	// Setup activity layout
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);

		getWindow().setFormat(PixelFormat.RGBX_8888); // <--- This makes xperia
														// play happy

		mUnityPlayer = new UnityPlayer(this);
		setContentView(mUnityPlayer);
		mUnityPlayer.requestFocus();
	}

	// Quit Unity
	@Override
	protected void onDestroy() {
		mUnityPlayer.quit();
		super.onDestroy();
	}

	// Pause Unity
	@Override
	protected void onPause() {
		super.onPause();
		mUnityPlayer.pause();
	}

	// Resume Unity
	@Override
	protected void onResume() {
		super.onResume();
		mUnityPlayer.resume();
	}

	// This ensures the layout will be correct.
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		mUnityPlayer.configurationChanged(newConfig);
	}

	// Notify Unity of the focus change.
	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
		mUnityPlayer.windowFocusChanged(hasFocus);
	}

	// For some reason the multiple keyevent type is not supported by the ndk.
	// Force event injection by overriding dispatchKeyEvent().
	@Override
	public boolean dispatchKeyEvent(KeyEvent event) {
		if (event.getAction() == KeyEvent.ACTION_MULTIPLE)
			return mUnityPlayer.injectEvent(event);
		return super.dispatchKeyEvent(event);
	}

	// Pass any events not handled by (unfocused) views straight to UnityPlayer
	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		return mUnityPlayer.injectEvent(event);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return mUnityPlayer.injectEvent(event);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		return mUnityPlayer.injectEvent(event);
	}

	/* API12 */public boolean onGenericMotionEvent(MotionEvent event) {
		return mUnityPlayer.injectEvent(event);
	}

	public String UnityToSDK(String data) {

		Log.i("UnityToSDK", data);

		Gson gson = new Gson();

		SDKMessage message = gson.fromJson(data, SDKMessage.class);

		DebugMessage(message);

		SDKMessageType type = SDKMessageType.values()[message.Type];

		if (message.Type == SDKMessageType.GetChannel.ordinal()) {
			return GetChannel();
		} else if (message.Type == SDKMessageType.Init.ordinal()) {
			Init();
		} else if (message.Type == SDKMessageType.Login.ordinal()) {
			Login();
		} else if (message.Type == SDKMessageType.Logout.ordinal()) {
			Logout();
		} else if (message.Type == SDKMessageType.UploadRoleInfo.ordinal()) {
			UploadRoleInfo(message);
		} else if (message.Type == SDKMessageType.Pay.ordinal()) {
			Pay(message);
		}

		return "null";
	}
	
	

	String GetChannel() {
		return "XiaoMi";
	}
	
	
	

	void Init() {
		//调用SDK的初始化

	}

	void Login() {
		//调用SDK的登入
	}

	void Logout() {
		//调用SDK的切换账号
	}

	void UploadRoleInfo(SDKMessage message) {
		//调用SDK的上传角色
	}

	void Pay(SDKMessage message) {
		//调用SDK的支付
	}
	
	
	
	

	void DebugMessage(SDKMessage message) {
		Log.i("UnityToSDK", "Type :" + message.Type);

		Log.i("UnityToSDK", "Money :" + message.Money);

		Log.i("UnityToSDK", "OrderId :" + message.OrderId);

		Log.i("UnityToSDK", "RechargeTime :" + message.RechargeTime);
		
		Log.i("UnityToSDK", "ProductID :" + message.ProductID);

		Log.i("UnityToSDK", "ProductName :" + message.ProductName);

		Log.i("UnityToSDK", "ProductDescription :" + message.ProductDescription);

		Log.i("UnityToSDK", "UploadRoleInfoType :" + message.UploadRoleInfoType);
		
		Log.i("UnityToSDK", "RoleId :" + message.RoleId);

		Log.i("UnityToSDK", "RoleName :" + message.RoleName);

		Log.i("UnityToSDK", "RoleLevel :" + message.RoleLevel);

		Log.i("UnityToSDK", "RoleProfessionalID :" + message.RoleProfessionalID);

		Log.i("UnityToSDK", "RoleProfessionalName :"
				+ message.RoleProfessionalName);

		Log.i("UnityToSDK", "RolePower :" + message.RolePower);
		
		Log.i("UnityToSDK", "CreateRoleTime :" + message.CreateRoleTime);
		
		Log.i("UnityToSDK", "RoleUpgradeTime :" + message.RoleUpgradeTime);

		Log.i("UnityToSDK", "Diamond :" + message.Diamond);

		Log.i("UnityToSDK", "AreaId :" + message.AreaId);

		Log.i("UnityToSDK", "ArenName :" + message.ArenName);

		Log.i("UnityToSDK", "VIPLevel :" + message.VIPLevel);

		Log.i("UnityToSDK", "GangID :" + message.GangID);

		Log.i("UnityToSDK", "GangName :" + message.GangName);

		Log.i("UnityToSDK", "CompanyName :" + message.CompanyName);

		Log.i("UnityToSDK", "UserID :" + message.UserID);

		Log.i("UnityToSDK", "Token :" + message.Token);

		Log.i("UnityToSDK", "ComplementaryVariable0 :"
				+ message.ComplementaryVariable0);

		Log.i("UnityToSDK", "ComplementaryVariable1 :"
				+ message.ComplementaryVariable1);

		Log.i("UnityToSDK", "ComplementaryVariable2 :"
				+ message.ComplementaryVariable2);

		Log.i("UnityToSDK", "ComplementaryVariable3 :"
				+ message.ComplementaryVariable3);

		Log.i("UnityToSDK", "ComplementaryVariable4 :"
				+ message.ComplementaryVariable4);

		Log.i("UnityToSDK", "ComplementaryVariable5 :"
				+ message.ComplementaryVariable5);

		Log.i("UnityToSDK", "ComplementaryVariable6 :"
				+ message.ComplementaryVariable6);

		Log.i("UnityToSDK", "ComplementaryVariable7 :"
				+ message.ComplementaryVariable7);

		Log.i("UnityToSDK", "ComplementaryVariable8 :"
				+ message.ComplementaryVariable8);

		Log.i("UnityToSDK", "ComplementaryVariable9 :"
				+ message.ComplementaryVariable9);

	}

}
