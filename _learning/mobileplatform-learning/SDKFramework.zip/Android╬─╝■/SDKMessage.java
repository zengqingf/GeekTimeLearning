package com.Company.SDKFramework;
enum SDKMessageType
{
	NUll,

	GetChannel,

	Init,
	Login,
	Logout,
	UploadRoleInfo,
	Pay,

	LoginSucceed,
	LogoutSucceed,


	/** 
	 补充的5个方法.
	*/
	ComplementaryMethod0,
	ComplementaryMethod1,
	ComplementaryMethod2,
	ComplementaryMethod3,
	ComplementaryMethod4;

	public static final int SIZE = java.lang.Integer.SIZE;

	public int getValue()
	{
		return this.ordinal();
	}

	public static SDKMessageType forValue(int value)
	{
		return values()[value];
	}
}

public class SDKMessage
{
	public SDKMessage(int type)
	{
		Type = type;
	}


	/** 
	 调用方法类型.
	*/
	public int Type = -1;










	/////////////////////////Unity 传递给 SDK 的数据.


	/** 
	 价格.
	*/
	public float Money = -1f;
	/** 
	 订单号
	*/
	public String OrderId = "";
	/** 
	 创建订单时间.
	*/
	public long RechargeTime = -1;
	/** 
	 商品ID.
	*/
	public int ProductID = -1;
	/** 
	 商品名字.
	*/
	public String ProductName = "";
	/** 
	 商品描述.
	*/
	public String ProductDescription = "";


	/** 
	 上传角色信息类型 创建 登入 升级 退出
	*/
	public int UploadRoleInfoType = -1;

	/** 
	 角色ID.
	*/
	public long RoleId = -1;
	/** 
	 角色名字.
	*/
	public String RoleName = "";
	/** 
	 角色等级.
	*/
	public int RoleLevel = -1;
	/** 
	 角色职业ID.
	*/
	public int RoleProfessionalID = -1;
	/** 
	 角色职业名字.
	*/
	public String RoleProfessionalName = "";
	/** 
	 角色战斗力.
	*/
	public int RolePower = -1;
	/** 
	 角色创建时间.
	*/
	public String CreateRoleTime = "";
	/** 
	 角色升级时间.
	*/
	public String RoleUpgradeTime = "";
	/** 
	 剩余钻石.
	*/
	public int Diamond = -1;
	/** 
	 区服ID.
	*/
	public int AreaId = -1;
	/** 
	 区服名字.
	*/
	public String ArenName = "";
	/** 
	 VIP等级.
	*/
	public int VIPLevel = -1;
	/** 
	 公会Id.
	*/
	public long GangID = -1;
	/** 
	 公会名字.
	*/
	public String GangName = "";
	/** 
	 公司名字.
	*/
	public String CompanyName = "";









	/////////////////////////SDK 传递给 Unity 的数据.








	/** 
	 用户ID.
	*/
	public String UserID = "";
	/** 
	 Token.
	*/
	public String Token = "";


















	/////////////////////////补充的10个变量.

	public String ComplementaryVariable0 = "";
	public String ComplementaryVariable1 = "";
	public String ComplementaryVariable2 = "";
	public String ComplementaryVariable3 = "";
	public String ComplementaryVariable4 = "";
	public String ComplementaryVariable5 = "";
	public String ComplementaryVariable6 = "";
	public String ComplementaryVariable7 = "";
	public String ComplementaryVariable8 = "";
	public String ComplementaryVariable9 = "";
}