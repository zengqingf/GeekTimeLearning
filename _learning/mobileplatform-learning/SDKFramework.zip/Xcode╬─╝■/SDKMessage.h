﻿#include <string>

enum SDKMessageType
{
    NUll,
    
    GetChannel,
    
    Init,
    Login,
    Logout,
    UploadRoleInfo,
    Pay,
    
    LoginSucceed,
    LogoutSucceed,
    
    
    /// <summary>
    /// 补充的5个方法.
    /// </summary>
    ComplementaryMethod0,
    ComplementaryMethod1,
    ComplementaryMethod2,
    ComplementaryMethod3,
    ComplementaryMethod4,
    
};

class SDKMessage
{
public:
    SDKMessage(int type)
    {
        Type = type;
    }
    
    
    /// <summary>
    /// 调用方法类型.
    /// </summary>
    int Type = -1;
    
    
    
    
    
    
    
    
    
    
    /////////////////////////Unity 传递给 SDK 的数据.
    
    
    /// <summary>
    /// 价格.
    /// </summary>
    float Money = -1.0f;
    /// <summary>
    /// 订单号
    /// </summary>
    const char *  OrderId = "";
    /// <summary>
    /// 创建订单时间.
    /// </summary>
    long long RechargeTime = -1;
    /// <summary>
    /// 商品ID.
    /// </summary>
    int ProductID = -1;
    /// <summary>
    /// 商品名字.
    /// </summary>
    const char * ProductName = "";
    /// <summary>
    /// 商品描述.
    /// </summary>
    const char * ProductDescription = "";
    
    
    /// <summary>
    /// 上传角色信息类型 创建 登入 升级 退出
    /// </summary>
    int UploadRoleInfoType = -1;
    
    /// <summary>
    /// 角色ID.
    /// </summary>
    long long RoleId = -1;
    /// <summary>
    /// 角色名字.
    /// </summary>
    const char * RoleName = "";
    /// <summary>
    /// 角色等级.
    /// </summary>
    int RoleLevel = -1;
    /// <summary>
    /// 角色职业ID.
    /// </summary>
    int RoleProfessionalID = -1;
    /// <summary>
    /// 角色职业名字.
    /// </summary>
    const char * RoleProfessionalName = "";
    /// <summary>
    /// 角色战斗力.
    /// </summary>
    int RolePower = -1;
    /// <summary>
    /// 角色创建时间.
    /// </summary>
    const char * CreateRoleTime = "";
    /// <summary>
    /// 角色升级时间.
    /// </summary>
    const char * RoleUpgradeTime = "";
    /// <summary>
    /// 剩余钻石.
    /// </summary>
    int Diamond = -1;
    /// <summary>
    /// 区服ID.
    /// </summary>
    int AreaId = -1;
    /// <summary>
    /// 区服名字.
    /// </summary>
    const char * ArenName = "";
    /// <summary>
    /// VIP等级.
    /// </summary>
    int VIPLevel = -1;
    /// <summary>
    /// 公会Id.
    /// </summary>
    long long GangID = -1;
    /// <summary>
    /// 公会名字.
    /// </summary>
    const char * GangName = "";
    /// <summary>
    /// 公司名字.
    /// </summary>
    const char * CompanyName = "";
    
    
    
    
    
    
    
    
    
    /////////////////////////SDK 传递给 Unity 的数据.
    
    
    
    
    
    
    
    
    /// <summary>
    /// 用户ID.
    /// </summary>
    const char * UserID = "";
    /// <summary>
    /// Token.
    /// </summary>
    const char * Token = "";
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /////////////////////////补充的10个变量.
    
    const char * ComplementaryVariable0 = "";
    const char * ComplementaryVariable1 = "";
    const char * ComplementaryVariable2 = "";
    const char * ComplementaryVariable3 = "";
    const char * ComplementaryVariable4 = "";
    const char * ComplementaryVariable5 = "";
    const char * ComplementaryVariable6 = "";
    const char * ComplementaryVariable7 = "";
    const char * ComplementaryVariable8 = "";
    const char * ComplementaryVariable9 = "";
};
