
#import "sys/utsname.h"
#include <iostream>


#include <sys/types.h>
#include <sys/sysctl.h>

#include <sys/sysctl.h>
#include <mach/mach.h>
#include <string>


#include <SDKMessage.h>

extern "C"
{
    // Helper method to create C string copy
    char* MakeStringCopy (const char* string)
    {
        if (string == NULL)
        {
            return NULL;
        }
        char* res = (char*)malloc(strlen(string) + 1);
        memset(res,0,strlen(string) + 1);
        strcpy(res, string);
        return res;
        
    }
    
    
    
    
    
    
    
    
    
    
    
    SDKMessage * Parse(const char * data)
    {
        SDKMessage * message = new SDKMessage(1);
        
        NSString * jsonString =[NSString stringWithUTF8String: data];
        
        NSLog(@"jsonString--->%@",jsonString);
        
        //将字符串写到缓冲区。
        NSData* jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
        
        //解析json数据，使用系统方法 JSONObjectWithData:  options: error:
        NSDictionary* dic = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableLeaves error:nil];
        
        //接下来一步一步解析。知道得到你想要的东西。
        message->Type =[[dic objectForKey:@"Type"]intValue];
        message->Money =[[dic objectForKey:@"Money"]floatValue];
        message->OrderId =[[dic objectForKey:@"OrderId"] UTF8String];
        message->RechargeTime =[[dic objectForKey:@"RechargeTime"]longLongValue];
        
        
        
        
        
        return message;
    }
    
    void DebugSDKMessage(SDKMessage * message)
    {
        NSLog(@"message->Type :%d" , message->Type);
        NSLog(@"message->Money :%f" , message->Money);
        NSLog(@"message->OrderId :%s" , message->OrderId);
        NSLog(@"message->RechargeTime :%lld" , message->RechargeTime);
        
    }
    
    void SDKToUnity(SDKMessage * message)
    {
        // 如果数组或者字典中存储了  NSString, NSNumber, NSArray, NSDictionary, or NSNull 之外的其他对象,就不能直接保存成文件了.也不能序列化成 JSON 数据.
        NSDictionary *dict = @{
                               @"Type" :[NSString stringWithFormat:@"%d", message->Type],
                               @"Money" : [NSString stringWithFormat:@"%f", message->Money],
                               @"OrderId" :[NSString stringWithUTF8String: message->OrderId],
                               @"RechargeTime" : [NSString stringWithFormat:@"%lld", message->RechargeTime],
                               @"UserID" :[NSString stringWithFormat:@"%s", message->UserID]
                               };
        
        // 1.判断当前对象是否能够转换成JSON数据.
        // YES if obj can be converted to JSON data, otherwise NO
        BOOL isYes = [NSJSONSerialization isValidJSONObject:dict];
        
        if (isYes) {
            NSLog(@"可以转换");
            
            /* JSON data for obj, or nil if an internal error occurs. The resulting data is a encoded in UTF-8.
             */
            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:NULL];
            
            /*
             Writes the bytes in the receiver to the file specified by a given path.
             YES if the operation succeeds, otherwise NO
             */
            // 将JSON数据写成文件
            // 文件添加后缀名: 告诉别人当前文件的类型.
            // 注意: AFN是通过文件类型来确定数据类型的!如果不添加类型,有可能识别不了! 自己最好添加文件类型.
            //[jsonData writeToFile:@"/Users/SunnyBoy/Sites/JSON_XML/dict.json" atomically:YES];
            
            NSLog(@"%@", [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding]);
            
            const char * data =[[[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding] UTF8String] ;
            
            UnitySendMessage("SDKManager", "SDKToUnity",  data);
            
            
            
        } else {
            
            NSLog(@"JSON数据生成失败，请检查数据格式");
            
        }
        
        
        
    }
    
    void LoginSDK()
    {
        SDKMessage * message = new SDKMessage(LoginSucceed);
        
        message->UserID = "UserID123456";
        message->Money = 1.11112;
        message->OrderId = "传递订单";
        //message->RechargeTime = 9223372036854775807;
        message->RechargeTime = 123456;
        
        
        
        SDKToUnity(message);
    }
    
    
    
    //Unity调用SDK方法;
    const char * UnityToPhoneSDK(const char * data)
    {
        NSString * Data = [NSString stringWithUTF8String: data];
        
        NSLog(@"UnityToPhoneSDK :%@", Data);
        
        SDKMessage * message = Parse(data);
        
        DebugSDKMessage(message);
        
        if(message->Type == Login)
        {
            LoginSDK();
        }
        
        
        std::string str = "UnityToSDK Defeated";
        
        
        return MakeStringCopy(str.c_str());
        
        
        
    }
    
    
    
}
