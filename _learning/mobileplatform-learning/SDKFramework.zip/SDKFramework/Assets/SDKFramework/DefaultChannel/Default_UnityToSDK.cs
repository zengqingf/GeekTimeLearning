﻿using UnityEngine;
using System.Collections;
using System;

public class Default_UnityToSDK : IUnityToSDK
{
    public void Init()
    {
        SDKConfig.Log("Default_UnityToSDK : Init()");

        SDKMessage message = new SDKMessage((int)SDKMessageType.Init);

		SDKManager.GetSingleton().UnityToSDK(message);
    }

    public void Login()
    {
        SDKConfig.Log("Default_UnityToSDK : Login()");

        SDKMessage message = new SDKMessage((int)SDKMessageType.Login);

		SDKManager.GetSingleton().UnityToSDK(message);
    }

    public void Logout()
    {
        SDKConfig.Log("Default_UnityToSDK : Logout()");

        SDKMessage message = new SDKMessage((int)SDKMessageType.Logout);

		SDKManager.GetSingleton().UnityToSDK(message);
    }

    public void UploadRoleInfo(SDKMessage message)
    {
        SDKConfig.Log("Default_UnityToSDK : UploadRoleInfo()");

        if (message == null)
        {
            message = new SDKMessage((int)SDKMessageType.UploadRoleInfo);
        }

		SDKManager.GetSingleton().UnityToSDK(message);
    }

    public void Pay(SDKMessage message)
    {
        SDKConfig.Log("Default_UnityToSDK : Pay()");

        if (message == null)
        {
            message = new SDKMessage((int)SDKMessageType.Pay);
        }

		SDKManager.GetSingleton().UnityToSDK(message);
    }

    public string Other(SDKMessage message)
    {
        SDKConfig.Log("Default_UnityToSDK : Other()");

        if (message == null)
        {
            message = new SDKMessage((int)SDKMessageType.ComplementaryMethod0);
        }

		return SDKManager.GetSingleton().UnityToSDK(message);
    }
}
