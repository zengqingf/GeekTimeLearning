﻿using UnityEngine;
using System.Collections;
using System;
using Pathfinding.Serialization.JsonFx;

public class SDKConfig
{
    /// <summary>
    /// 统一控制日志.
    /// </summary>
    /// <param name="str"></param>
    public static void Log(string str)
    {
        Debug.Log("SDKConfig Log:" + str);
    }

    /// <summary>
    /// 打印信息信息.
    /// </summary>
    /// <param name="message">Message.</param>
    public static void ShowSDKMessageInfo(SDKMessage message)
    {
        Log("SDKConfig : ShowSDKMessageInfo Type:" + message.Type);
        Log("SDKConfig : ShowSDKMessageInfo Money:" + message.Money);
        Log("SDKConfig : ShowSDKMessageInfo OrderId:" + message.OrderId);
        Log("SDKConfig : ShowSDKMessageInfo RechargeTime:" + message.RechargeTime);
        Log("SDKConfig : ShowSDKMessageInfo ProductID:" + message.ProductID);
        Log("SDKConfig : ShowSDKMessageInfo ProductName:" + message.ProductName);
        Log("SDKConfig : ShowSDKMessageInfo ProductDescription:" + message.ProductDescription);
        Log("SDKConfig : ShowSDKMessageInfo UploadRoleInfoType:" + message.UploadRoleInfoType);
        Log("SDKConfig : ShowSDKMessageInfo RoleId:" + message.RoleId);
        Log("SDKConfig : ShowSDKMessageInfo RoleName:" + message.RoleName);
        Log("SDKConfig : ShowSDKMessageInfo RoleLevel:" + message.RoleLevel);
        Log("SDKConfig : ShowSDKMessageInfo RoleProfessionalID:" + message.RoleProfessionalID);
        Log("SDKConfig : ShowSDKMessageInfo RoleProfessionalName:" + message.RoleProfessionalName);
        Log("SDKConfig : ShowSDKMessageInfo RolePower:" + message.RolePower);
        Log("SDKConfig : ShowSDKMessageInfo CreateRoleTime:" + message.CreateRoleTime);
        Log("SDKConfig : ShowSDKMessageInfo RoleUpgradeTime:" + message.RoleUpgradeTime);
        Log("SDKConfig : ShowSDKMessageInfo Diamond:" + message.Diamond);
        Log("SDKConfig : ShowSDKMessageInfo AreaId:" + message.AreaId);
        Log("SDKConfig : ShowSDKMessageInfo ArenName:" + message.ArenName);
        Log("SDKConfig : ShowSDKMessageInfo VIPLevel:" + message.VIPLevel);
        Log("SDKConfig : ShowSDKMessageInfo GangID:" + message.GangID);
        Log("SDKConfig : ShowSDKMessageInfo GangName:" + message.GangName);
        Log("SDKConfig : ShowSDKMessageInfo CompanyName:" + message.CompanyName);
        Log("SDKConfig : ShowSDKMessageInfo UserID:" + message.UserID);
        Log("SDKConfig : ShowSDKMessageInfo ComplementaryVariable0:" + message.ComplementaryVariable0);
        Log("SDKConfig : ShowSDKMessageInfo ComplementaryVariable1:" + message.ComplementaryVariable1);
        Log("SDKConfig : ShowSDKMessageInfo ComplementaryVariable2:" + message.ComplementaryVariable2);
        Log("SDKConfig : ShowSDKMessageInfo ComplementaryVariable3:" + message.ComplementaryVariable3);
        Log("SDKConfig : ShowSDKMessageInfo ComplementaryVariable4:" + message.ComplementaryVariable4);
        Log("SDKConfig : ShowSDKMessageInfo ComplementaryVariable5:" + message.ComplementaryVariable5);
        Log("SDKConfig : ShowSDKMessageInfo ComplementaryVariable6:" + message.ComplementaryVariable6);
        Log("SDKConfig : ShowSDKMessageInfo ComplementaryVariable7:" + message.ComplementaryVariable7);
        Log("SDKConfig : ShowSDKMessageInfo ComplementaryVariable8:" + message.ComplementaryVariable8);
        Log("SDKConfig : ShowSDKMessageInfo ComplementaryVariable9:" + message.ComplementaryVariable9);
    }

    /// <summary>
    /// 类转换为JSON格式的STRING.
    /// </summary>
    /// <returns>The to json.</returns>
    /// <param name="message">Message.</param>
    public static string ClassToJson(SDKMessage message)
    {

        //在这里可以替换自己工程使用的JSON插件

        return JsonWriter.Serialize(message);
    }

    /// <summary>
    /// JJSON格式的STRING转换类.
    /// </summary>
    /// <returns>The to class.</returns>
    /// <param name="message">Message.</param>
    public static SDKMessage JsonToClass(string message)
    {
        //在这里可以替换自己工程使用的JSON插件

        return JsonReader.Deserialize<SDKMessage>(message); ;
    }

    /// <summary>
    /// 如果渠道有特殊的需求
    /// 在这里判断 
    /// 创建对应的渠道类
    /// </summary>
    /// <param name="channelName">渠道名</param>
    /// <returns></returns>
    public static IUnityToSDK GetUnityToSDK(string channelName)
    {
        if (Application.platform == RuntimePlatform.WindowsEditor)
        {

        }

        IUnityToSDK UnityToSDK = new Default_UnityToSDK();

        if (channelName == "XiaoMi")
        {
            //channel = new XiaoMiChannel();
        }

        return UnityToSDK;
    }

    /// <summary>
    /// 如果渠道有特殊的需求
    /// 在这里判断 
    /// 创建对应的回调类
    /// </summary>
    /// <param name="channelName"></param>
    /// <returns></returns>
    public static ISDKToUnity GetSDKToUinty(string channelName)
    {
        ISDKToUnity SDKToUnity = new Default_SDKToUnity();

        if (channelName == "XiaoMi")
        {
            //callBack = new XiaoMiCallBack();
        }

        return SDKToUnity;
    }







    /// <summary>
    /// 获取上传角色相关数据;
    /// </summary>
    /// <param name="message"></param>
    /// <returns></returns>
    public static SDKMessage GetUploadRoleInfo()
    {
        SDKMessage message = new SDKMessage((int)SDKMessageType.UploadRoleInfo);

        //在这里把你游戏中的相关信息 全部赋值
        message.RoleId = 1022222222;






        return message;
    }

    /// <summary>
    /// 获取支付相关数据;
    /// </summary>
    /// <param name="message"></param>
    /// <returns></returns>
    public static SDKMessage GetPayInfo()
    {
        SDKMessage message = new SDKMessage((int)SDKMessageType.Pay);

        //在这里把你游戏中的相关信息 全部赋值
        message.Money = 10;
        message.OrderId = Guid.NewGuid().ToString("N").Substring(0, 30);





        return message;
    }






    /// <summary>
    /// 登录.
    /// </summary>
    /// <param name="userID"></param>
    public static void LoginSucceed(string userID)
    {
        //参数为SDK获取来的玩家用户ID
        //在这里做游戏登录操作


    }

    /// <summary>
    /// 注销.
    /// </summary>
    /// <param name="userID"></param>
    public static void LogoutSucceed()
    {

        //SDK浮标进行的注销  
        //在这里做返回登录界面的操作和再次调用SDK登录功能


    }

}
