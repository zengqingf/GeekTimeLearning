﻿using UnityEngine;


public class UI : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }



    private void OnGUI()
    {
        if (GUI.Button(new Rect(0, 0, 100, 50), "初始化"))
        {
            SDKManager.GetSingleton().IUnityToSDK.Init();
        }

        if (GUI.Button(new Rect(0, 50, 100, 50), "登录"))
        {
            SDKManager.GetSingleton().IUnityToSDK.Login();
        }

        if (GUI.Button(new Rect(0, 100, 100, 50), "上传角色信息"))
        {
            SDKMessage messgae = SDKConfig.GetUploadRoleInfo();

            SDKManager.GetSingleton().IUnityToSDK.UploadRoleInfo(messgae);
        }

        if (GUI.Button(new Rect(0, 150, 100, 50), "支付"))
        {
            SDKMessage messgae = SDKConfig.GetPayInfo();

            SDKManager.GetSingleton().IUnityToSDK.Pay(messgae);
        }

        if (GUI.Button(new Rect(0, 200, 100, 50), "注销"))
        {
            SDKManager.GetSingleton().IUnityToSDK.Logout();
        }
    }
}
