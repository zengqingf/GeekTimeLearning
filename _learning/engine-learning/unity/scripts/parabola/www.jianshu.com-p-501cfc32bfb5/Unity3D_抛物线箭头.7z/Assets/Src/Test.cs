﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetMouseButton(0)) {
			var ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			var ret = new RaycastHit();
			if (Physics.Raycast(ray, out ret)) {
				if (transform == ret.transform) {
					var end = transform.InverseTransformPoint(ret.point);
					end.x *= transform.localScale.x;
					end.y *= transform.localScale.y;
					end.z *= transform.localScale.z;
					GameObject.Find("Line").GetComponent<Line>().Draw(end);
				}
			}
		}
	}
}
