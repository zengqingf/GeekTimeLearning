﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Line : MonoBehaviour {

	public Vector3 Normal;

	public float LineHeight;

	public float ArrowSize;

	public float BlockSize;

	public GameObject Arrow;

	public GameObject Block;

	private float _a, _b, _c;

	private float _distance;

	private float _offset = 0;

	private List<GameObject> _blocks;

	public void Draw(Vector2 end) {
		if (IsDraw(end.magnitude)) {
			Computer(end.magnitude);
			ChangeArrow(end.magnitude);
			ChangeBlock(end.magnitude);
			ChangeAngle(end);
		}
		else {
			Clear();
		}
	}

	private void Computer(float distance) {
		var start = Vector2.zero;
		var last = new Vector2(distance, 0);
		var mid = new Vector2(distance / 2, LineHeight);

		_b = ((start.y - last.y) * (start.x * start.x - mid.x * mid.x) - 
			(start.y - mid.y) * (start.x * start.x- last.x * last.x)) / 
			((start.x - last.x) * (start.x * start.x - mid.x * mid.x) - (start.x- mid.x) * (start.x * start.x - last.x * last.x));

		_a = ((start.y - mid.y) - _b * (start.x - mid.x)) / (start.x * start.x - mid.x * mid.x);

		_c = start.y - _a * start.x * start.x - _b * start.x;

		_distance = distance;
	}

	private void Clear() {
		for (var i = 0; i != _blocks.Count; ++i) {
			DestroyImmediate(_blocks[i]);
		}
		_blocks.Clear();
		_distance = 0;
	}

	private void Start() {
		_blocks = new List<GameObject>();
	}

	private bool IsDraw(float distance) {
		return distance > BlockSize * 3;
	}

	private void Update() {
		if (IsDraw(_distance)) {
			ChangeBlock(_distance);
		}
	}

	private void ChangeArrow(float distance) {
		//Arrow.transform.localPosition = end;
	}

	private void ChangeBlock(float distance) {
		var numBlock = ResetBlock(distance);
		for (var i = 0; i != numBlock; ++i) {
			var curr = GetBlockPos(i);
			var next = GetBlockPos(i + 1);

			var nodeTransform = _blocks[i].transform;
			var axisY = Mathf.Atan2(next.z - curr.z, next.x - curr.x);
			var quate = Quaternion.Euler(0, -axisY * Mathf.Rad2Deg, 0);
			nodeTransform.localPosition = curr;
			nodeTransform.localRotation = quate;
		}
	}

	private Vector3 GetBlockPos(int i) {
		var ret = new Vector3() {
			x = (i + _offset) * BlockSize
		};
		if (ret.x - BlockSize > _distance) {
			ret.x -= (int)(ret.x / _distance) * _distance;
		}
		ret.z = -(_a * ret.x * ret.x + _b * ret.x + _c);
		return ret;
	}

	private void ChangeAngle(Vector2 end) {
		var angleZ = Mathf.Atan2(end.y, end.x) * Mathf.Rad2Deg;
		transform.localRotation = Quaternion.Euler(0, 0, angleZ);
	}

	private int ResetBlock(float distance) {
		var numBlock = (int)(distance / BlockSize) + 1;
		var addBlock = numBlock - _blocks.Count;
		if (addBlock > 0) {
			var mid = _blocks.Count / 2;
			for (var i = 0; i != addBlock; ++i) {
				_blocks.Insert(mid, Instantiate(Block, transform));
			}
		}
		else if (addBlock < 0) {
			for (var i = 0; i != addBlock; --i) {
				var mid = _blocks.Count / 2;
				Destroy(_blocks[mid]);
				_blocks.RemoveAt(mid);
			}
		}
		return numBlock;
	}

	public Vector2 CheckPosition(Ray ray) {
		var n = Normal;
		var o = ray.origin;
		var d = ray.direction;
		var oDotN = Vector3.Dot(o, n);
		if (oDotN < 0) {
			var dDotN = Vector3.Dot(d, n);
			var end = o + d * oDotN / dDotN;
			return transform.localPosition - end;
		}
		return Vector2.zero;
	}
}
