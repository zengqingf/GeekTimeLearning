// Copyright Epic Games, Inc. All Rights Reserved.

// This is an experimental integration and requires custom FASTBuild binaries available in Engine/Extras/ThirdPartyNotUE/FASTBuild
// Currently only Windows, Mac, iOS and tvOS targets are supported.

///////////////////////////////////////////////////////////////////////////
// Copyright 2018 Yassine Riahi and Liam Flookes. Provided under a MIT License, see license file on github.
// Used to generate a fastbuild .bff file from UnrealBuildTool to allow caching and distributed builds.
///////////////////////////////////////////////////////////////////////////
// Modified by Nick Edwards @ Sumo Digital to implement support for building on
// MacOS for MacOS, iOS and tvOS targets. Includes RiceKab's alterations for
// providing 4.21 support (https://gist.github.com/RiceKab/60d7dd434afaab295d1c21d2fe1981b0)
///////////////////////////////////////////////////////////////////////////

using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Text;
using System.Threading;
using Tools.DotNETCommon;

namespace UnrealBuildTool
{

	///////////////////////////////////////////////////////////////////////
	internal static class VCEnvironmentFastbuildExtensions
	{
		/// <summary>
		/// This replaces the VCToolPath64 readonly property that was available in 4.19 . Note that GetVCToolPath64
		/// is still used internally, but the property for it is no longer exposed.
		/// </summary>
		/// <param name="VCEnv"></param>
		/// <returns></returns>
		public static DirectoryReference GetToolPath(this VCEnvironment VCEnv)
		{
			return VCEnv.CompilerPath.Directory;
		}

		/// <summary>
		/// This replaces the InstallDir readonly property that was available in 4.19.
		///
		///
		/// </summary>
		/// <param name="VCEnv"></param>
		/// <returns></returns>
		public static DirectoryReference GetVCInstallDirectory(this VCEnvironment VCEnv)
		{
			// TODO: Check registry values before moving up ParentDirectories (as in 4.19)
			return VCEnv.ToolChainDir.ParentDirectory.ParentDirectory.ParentDirectory;
		}
		public static DirectoryReference GetWindowsSDKToolPath(this VCEnvironment VCEnv)
		{
			return VCEnv.ResourceCompilerPath.Directory;
		}
	}

	///////////////////////////////////////////////////////////////////////

	internal enum FASTBuildCacheMode
	{
		ReadWrite, // This machine will both read and write to the cache
		ReadOnly,  // This machine will only read from the cache, use for developer machines when you have centralized build machines
		WriteOnly, // This machine will only write from the cache, use for build machines when you have centralized build machines
	}

	///////////////////////////////////////////////////////////////////////

	class FASTBuild : ActionExecutor
	{
		/// <summary>
		/// 禁用PCH，由于MSCL的Bug，导致PCH存在时预处理不会输出头文件
		/// </summary>
		private bool usePCH_Windows = false;
		private TargetDescriptor targetDescriptor;
		private HashSet<string> aliasNames = new HashSet<string>();
		private Dictionary<string, string> id2AliasNames = new Dictionary<string, string>();

		//private UnrealTargetPlatform targetPlatform;
		public FASTBuild(TargetDescriptor targetDescriptor)
		{
			this.targetDescriptor = targetDescriptor;
		}
		[DllImport("kernel32.dll", EntryPoint = "GetSystemDefaultLCID")]
		static extern ushort GetSystemDefaultLCID();//OS 当前选择的默认语言（区域-管理）

		public readonly static string DefaultExecutableBasePath = Path.Combine(UnrealBuildTool.EngineDirectory.FullName, "Extras", "ThirdPartyNotUE", "FASTBuild");

		//////////////////////////////////////////
		// Tweakables

		/////////////////
		// Executable

		/// <summary>
		/// Used to specify the location of fbuild.exe if the distributed binary isn't being used
		/// </summary>
		[XmlConfigFile]
		public static string FBuildExecutablePath = null;

		/////////////////
		// Distribution

		/// <summary>
		/// Controls network build distribution
		/// </summary>
		[XmlConfigFile]
		public static bool bEnableDistribution = true;

		/// <summary>
		/// Used to specify the location of the brokerage. If null, FASTBuild will fall back to checking FASTBUILD_BROKERAGE_PATH
		/// </summary>
		[XmlConfigFile]
		public static string FBuildBrokeragePath = null;

		/////////////////
		// Caching

		/// <summary>
		/// Controls whether to use caching at all. CachePath and FASTCacheMode are only relevant if this is enabled.
		/// </summary>
		[XmlConfigFile]
		public static bool bEnableCaching = true;

		/// <summary>
		/// Cache access mode - only relevant if bEnableCaching is true;
		/// </summary>
		[XmlConfigFile]
		public static FASTBuildCacheMode CacheMode = FASTBuildCacheMode.ReadWrite;

		/// <summary>
		/// Used to specify the location of the cache. If null, FASTBuild will fall back to checking FASTBUILD_CACHE_PATH
		/// </summary>
		[XmlConfigFile]
		public static string FBuildCachePath = null;

		/////////////////
		// Misc Options

		/// <summary>
		/// Whether to force remote
		/// </summary>
		[XmlConfigFile]
		public static bool bForceRemote = false;

		/// <summary>
		/// Whether to stop on error
		/// </summary>
		[XmlConfigFile]
		public static bool bStopOnError = true;

		/// <summary>
		/// Which MSVC CRT Redist version to use
		/// </summary>
		[XmlConfigFile]
		public static String MsvcCRTRedistVersion = "";

		//////////////////////////////////////////

		public override string Name
		{
			get { return "FASTBuild"; }
		}

		public static bool IsAvailable()
		{

			string exeName = "FBuild";

			if (BuildHostPlatform.Current.Platform == UnrealTargetPlatform.Win64)
			{
				exeName = "FBuild.exe";
			}

			FBuildExecutablePath = GetExecutablePath();
			if (!string.IsNullOrEmpty(FBuildExecutablePath) && File.Exists(FBuildExecutablePath))
			{
				return true;
			}
			FBuildExecutablePath = Path.Combine(DefaultExecutableBasePath, BuildHostPlatform.Current.Platform.ToString(), exeName);
			if (!string.IsNullOrEmpty(FBuildExecutablePath) && File.Exists(FBuildExecutablePath))
			{
				return true;
			}
			// Search the path for it
			string PathVariable = Environment.GetEnvironmentVariable("PATH");
			foreach (string SearchPath in PathVariable.Split(Path.PathSeparator))
			{
				try
				{
					string PotentialPath = Path.Combine(SearchPath, exeName);
					if (File.Exists(PotentialPath))
					{
						FBuildExecutablePath = PotentialPath;
						return true;
					}
				}
				catch (ArgumentException)
				{
					// PATH variable may contain illegal characters; just ignore them.
				}
			}

			string brokeragePath = GetBrokeragePath();
			if (!string.IsNullOrEmpty(brokeragePath) && Directory.Exists(brokeragePath))
			{
				return true;
			}

			Log.TraceError("FASTBuild disabled. Unable to find any executable to use.");
			return false;
		}



		private readonly HashSet<string> ForceLocalCompileModules = new HashSet<string>()
		{
			"Module.ProxyLODMeshReduction"
		};

		private enum CompilerToolchainType
		{
			MSVC,
			Clang,
			GCC
		}
		private enum CodeCompiler
		{
			MSCL,
			Clang,
			ClangPP,
			GCC
		}
		private enum LinkCompiler
		{
			UEMSLinkFilter,
			MSLink,
			MSLib,
			clang,
			clangPP

		}
		private enum LinkOutputType
		{
			StaticLib,
			DynamicLib,
			Exec
		}
		private enum ResCompiler
		{
			MSRC,
		}

		static List<Action> noCompileAction = new List<Action>();
		static List<PCHAction> pchCompileAction = new List<PCHAction>();
		static List<string> PCHFilePaths = new List<string>();
		static List<RCAction> rcCompileAction = new List<RCAction>();
		static List<CodeCompileAction> codeCompileAction = new List<CodeCompileAction>();
		static List<LinkAction> linkAction = new List<LinkAction>();

		private void Clear()
		{
			noCompileAction.Clear();
			pchCompileAction.Clear();
			PCHFilePaths.Clear();
			rcCompileAction.Clear();
			codeCompileAction.Clear();
			linkAction.Clear();
		}
		public override bool ExecuteActions(List<Action> Actions, bool bLogDetailedActionStats)
		{
			Clear();

			if (Actions.Count <= 0)
				return true;

			//pch rc
			//cpp
			//link
			//other
			var tmp = new List<Tuple<Action, LinkCompiler>>();

			foreach (var a in Actions)
			{
				if (a.ActionType == ActionType.Compile)
				{
					var cp = GetCompilerPath(a);
					var fileNameNoExt = Path.GetFileNameWithoutExtension(cp);
					Log.TraceInformation(fileNameNoExt);

					switch (fileNameNoExt)
					{
						case "cl":

						case "clang++":
						case "clang":
							if (IsPCHAction(a))
							{
								pchCompileAction.Add(new PCHAction(a));
							}
							else
							{
								codeCompileAction.Add(new CodeCompileAction(a));
							}
							break;
						case "rc":
							var na = new RCAction(a);
							rcCompileAction.Add(na);
							break;
						case "ispc":
							throw new Exception($"未处理{fileNameNoExt}");
						default:
							throw new Exception($"未知类型{fileNameNoExt}");
					}
				}
				else if (a.ActionType == ActionType.Link)
				{
					var cp = GetCompilerPath(a);
					var fileNameNoExt = Path.GetFileNameWithoutExtension(cp);
					switch (fileNameNoExt)
					{
						case "clang++":
							tmp.Add(new Tuple<Action, LinkCompiler>(a, LinkCompiler.clangPP));
							break;
						case "clang":
							tmp.Add(new Tuple<Action, LinkCompiler>(a, LinkCompiler.clang));
							break;
						case "link-filter":
							tmp.Add(new Tuple<Action, LinkCompiler>(a, LinkCompiler.UEMSLinkFilter));
							break;
						case "link":
							tmp.Add(new Tuple<Action, LinkCompiler>(a, LinkCompiler.MSLink));
							break;
						case "lib":
							tmp.Add(new Tuple<Action, LinkCompiler>(a, LinkCompiler.MSLib));
							break;
						default:
							throw new Exception($"未知链接类型{fileNameNoExt}");
					}
				}
				else
				{
					noCompileAction.Add(a);
				}
			}

			foreach (var item in tmp)
			{
				linkAction.Add(new LinkAction(item.Item1, item.Item2));
			}


			///////////////////////////////////////////////////////////////
			// Compile Stage
			//if (rcCompileAction.Count != 0)
			//{
			//    bool bResult = new LocalExecutor().ExecuteActions(ExtAction2Action(rcCompileAction), bLogDetailedActionStats);
			//    if (!bResult)
			//        return false;
			//}
			if (codeCompileAction.Count != 0)
			{
				string FASTBuildFilePath = Path.Combine(UnrealBuildTool.EngineDirectory.FullName, "Intermediate", "Build", "fbuild.bff");
				if (!CreateBffFile(FASTBuildFilePath))
					return false;
				if (!ExecuteBffFile(FASTBuildFilePath))
					return false;
			}
			else if (Actions.Count != 0)
			{
				bool bResult = new LocalExecutor().ExecuteActions(Actions, bLogDetailedActionStats);
				if (!bResult)
					return false;
			}

			///////////////////////////////////////////////////////////////
			// Post Compile Stage


			//if (noCompileAction.Count != 0)
			//{
			//    bool bResult = new LocalExecutor().ExecuteActions(noCompileAction, bLogDetailedActionStats);
			//    if (!bResult)
			//        return false;
			//}


			return true;
		}
		private List<Action> ExtAction2Action<T>(List<T> actions) where T : ExtAction

		{
			List<Action> ret = new List<Action>();
			foreach (var item in actions)
			{
				ret.Add(item.rawAction);
			}
			return ret;
		}

		private void AddText(string StringToWrite)
		{
			byte[] Info = new System.Text.UTF8Encoding(true).GetBytes(StringToWrite);
			bffOutputMemoryStream.Write(Info, 0, Info.Length);
		}

		private void AddPreBuildDependenciesText(IEnumerable<Action> PreBuildDependencies)
		{
			if (!PreBuildDependencies.Any())
				return;

			AddText($"\t.PreBuildDependencies = {{\n");
			AddText($"{string.Join("\n", PreBuildDependencies.Select(ActionToDependencyString))}'\n");
			AddText($"\t}} \n");
		}

		private MemoryStream bffOutputMemoryStream = null;

		private bool CreateBffFile(string BffFilePath)
		{
			bffOutputMemoryStream = new MemoryStream();
			bool ret = true;
			AddText(";*************************************************************************\n");
			AddText(";* Autogenerated bff - see FASTBuild.cs for how this file was generated. *\n");
			AddText(";*************************************************************************\n\n");

			//编译器都创建一下，只有用到了才会同步
			if (BuildHostPlatform.Current.Platform == UnrealTargetPlatform.Win64)
			{
				CreateBffFile_Windows();
				CreateBffFile_Android();
			}
			else if (BuildHostPlatform.Current.Platform == UnrealTargetPlatform.Mac)
			{
				CreateBffFile_Mac();
			}

			try
			{
				//rc
				foreach (var item in rcCompileAction)
				{
					CreateBffFile_ExecAction(item.rawAction, item.rawAction.ProducedItems[0].FullName);
				}

				//不在编译中用PCH，但是还是得生成走完完整流程
				foreach (var item in pchCompileAction)
				{
					if (item.codeCompiler == CodeCompiler.MSCL && !usePCH_Windows)
					{
						var actionID = ActionToActionString(item.rawAction);
						var tempDepFile = item.CLFilterHeader;
						var dep = GetValueFromCommandArgs(ref tempDepFile, "-dependencies=", removeIt: true);
						var pchNoCLFilterCmd = item.fastBuildPCHCompileArgs;

						var pchHeanderFile = GetValueFromCommandArgs(ref pchNoCLFilterCmd, $"/Yc", noQuotation: true, removeIt: true);
						var pchFile = GetValueFromCommandArgs(ref pchNoCLFilterCmd, $"/Fp", noQuotation: true, removeIt: true);

						var tempCppPath = Path.Combine(Path.GetDirectoryName(item.outputFilePath), $"{actionID}_temp.cpp");
						File.WriteAllText(tempCppPath, $"#include \"{pchHeanderFile}\"\n");

						AddText($"ObjectList('{actionID}')\n{{\n");
						AddText($"\t.Compiler = 'msvc'\n");
						AddText($"\t.CompilerInputFiles = '{tempCppPath}'\n");
						AddText($"\t.CompilerOutputPath = '{Path.GetDirectoryName(tempCppPath)}'\n");
						AddText($"\t.CompilerOptions = '\"%1\" /Fo\"%2\" /Yu\"{pchHeanderFile}\" /Fp\"{pchFile}\" {pchNoCLFilterCmd}'\n");

						AddText($"\t.PCHInputFile = '{item.inputFilePath}'\n");//.cpp
						AddText($"\t.PCHOutputFile = '{pchFile}'\n");//.pch
						AddText($"\t.PCHOptions = '/Yc\"{pchHeanderFile}\" /Fp\"%2\" \"%1\" /Fo\"{item.outputFilePath}\" {pchNoCLFilterCmd}'\n");
						//如果不加预处理器，通过cl-filter生成的依赖会被后续编译覆盖
						AddText($"\t.Preprocessor = 'cl-filter'\n");
						AddText($"\t.PreprocessorOptions = '{item.rawAction.CommandArguments}'\n");

						AddText($"\t.AllowDistribution = false\n");
						AddText("}\n\n");

					}
					else
					{
						var actionID = ActionToActionString(item.rawAction);
						var tempDepFile = item.CLFilterHeader;
						var dep = GetValueFromCommandArgs(ref tempDepFile, "-dependencies=", removeIt: true);
						var pchFile = item.outputFilePath;
						var pchHeanderFile = item.inputFilePath;

						var compileArgs = item.fastBuildPCHCompileArgs;
						//需要替换这个-x c++-header/c-header为-x c++
						var compileType = GetValueFromCommandArgs(ref compileArgs, "-x", noQuotation: true, removeIt: true);
						compileType = compileType.Replace("-header", "");
						var useCompiler = "clang++";
						if (item.codeCompiler == CodeCompiler.Clang)
						{
							useCompiler = "clang";
						}
						//去除依赖输出
						GetValueFromCommandArgs(ref compileArgs, "-MF", noQuotation: true, removeIt: true);
						GetValueFromCommandArgs(ref compileArgs, "-MD", noQuotation: true, removeIt: true);
						GetValueFromCommandArgs(ref compileArgs, "-M", noQuotation: true, removeIt: true);

						var tempCppPath = Path.Combine(Path.GetDirectoryName(item.outputFilePath), $"{actionID}_temp.cpp");
						File.WriteAllText(tempCppPath, $"#include \"{pchHeanderFile}\"\n");

						//clang 只会输出一种输出，不能实现预处理和头文件依赖一起输出，所以不能在预编译头阶段产生头文件依赖
						AddText($"ObjectList('{actionID}')\n{{\n");
						AddText($"\t.Compiler = '{useCompiler}'\n");
						AddText($"\t.CompilerInputFiles = '{tempCppPath}'\n");
						AddText($"\t.CompilerOutputPath = '{Path.GetDirectoryName(tempCppPath)}'\n");
						AddText($"\t.CompilerOptions = '-x {compileType} \"%1\" -o \"%2\" -include-pch \"{pchFile}\" {compileArgs}'\n");

						AddText($"\t.PCHInputFile = '{pchHeanderFile}'\n");//.h
						AddText($"\t.PCHOutputFile = '{pchFile}'\n");//-arm64.h.gch
						AddText($"\t.PCHOptions = '\"%1\" -o \"%2\" {item.fastBuildPCHCompileArgs}'\n");
						AddText($"\t.Preprocessor = '{useCompiler}'\n");
						//要去除-o操作，因为-o会导致预处理输出到文件而不是stdout
						//-M -MF和-E预处理是同属预处理操作，只能输出一种
						//-MD -MF是编译操作，加-E可以同时输出预处理数据和头文件依赖
						//ubt生成的action是用-MD操作
						AddText($"\t.PreprocessorOptions = '{item.compilerArgs}'\n");

						AddText($"\t.AllowDistribution = false\n");
						AddText("}\n\n");
					}
				}
				//cpp
				foreach (var Action in codeCompileAction)
				{
					AddText($";** Function for CompileAction {GetActionID(Action.rawAction)} **\n");
					AddText($";** CommandPath: {Action.rawAction.CommandPath.FullName}\n");
					AddText($";** CommandArguments: {Action.rawAction.CommandArguments}\n");
					AddText("\n");
					// Resolve the list of prerequisite items for this action to
					// a list of actions which produce these prerequisites
					//IEnumerable<Action> DependencyActions = Action.rawAction.PrerequisiteActions.Distinct();

					CreateBffFile_CompileAction(Action);


				}
				//lib、dll、exe
				foreach (var Action in linkAction)
				{
					AddText($";** Function for LinkAction {GetActionID(Action.rawAction)} **\n");
					AddText($";** CommandPath: {Action.rawAction.CommandPath.FullName}\n");
					AddText($";** CommandArguments: {Action.rawAction.CommandArguments}\n");
					AddText("\n");
					//Resolve the list of prerequisite items for this action to

					//a list of actions which produce these prerequisites

					IEnumerable<Action> DependencyActions = Action.rawAction.PrerequisiteActions.Distinct();

					CreateBffFile_LinkAction(Action);

				}
				//ubt

				foreach (var item in noCompileAction)
				{
					CreateBffFile_ExecAction(item, item.ProducedItems[0].FullName);
				}

				//string JoinedActions = codeCompileAction
				//	.Select(Action => ActionToDependencyString(Action.rawAction))
				//	.DefaultIfEmpty(string.Empty)
				//	.Aggregate((str, obj) => str + "\n" + obj);

				AddText("Alias( 'all' ) \n{\n");
				AddText("\t.Targets = { \n");
				//AddText(JoinedActions);
				foreach (var item in codeCompileAction)
				{
					AddText($"\t\t{ActionToDependencyString(item.rawAction)}\n");
				}
				foreach (var item in pchCompileAction)
				{
					AddText($"\t\t{ActionToDependencyString(item.rawAction)}\n");
				}
				foreach (var item in linkAction)
				{
					AddText($"\t\t{ActionToDependencyString(item.rawAction)}\n");
				}
				foreach (var item in rcCompileAction)
				{
					AddText($"\t\t{ActionToDependencyString(item.rawAction)}\n");
				}
				foreach (var item in noCompileAction)
				{
					AddText($"\t\t{ActionToDependencyString(item)}\n");
				}
				AddText("\n\t}\n");
				AddText("}\n");

				using (FileStream bffOutputFileStream = new FileStream(BffFilePath, FileMode.Create, FileAccess.Write))
				{
					bffOutputMemoryStream.Position = 0;
					bffOutputMemoryStream.CopyTo(bffOutputFileStream);
				}

				bffOutputMemoryStream.Close();
			}
			catch (Exception e)
			{
				Log.TraceError("Exception while creating bff file: " + e.ToString());
				ret = false;
			}

			return ret;
		}
		private void CreateBffFile_CompileAction(CodeCompileAction a)
		{
			switch (a.codeCompiler)
			{
				case CodeCompiler.MSCL:
					CreateBffFile_CompileAction_MSVC(a);
					break;
				case CodeCompiler.Clang:
					CreateBffFile_CompileAction_Clang(a, false);
					break;
				case CodeCompiler.ClangPP:
					CreateBffFile_CompileAction_Clang(a, true);
					break;
				case CodeCompiler.GCC:
					CreateBffFile_CompileAction_GCC(a);
					break;
				default:
					break;
			}

		}

		private void CreateBffFile_CompileAction_MSVC(CodeCompileAction action)
		{

			//RegistAliasNames(action.rawAction, action.outputFilePath);
			AddText($"ObjectList('{ActionToActionString(action.rawAction)}')\n{{\n");
			AddText($"\t.Compiler = 'msvc'\n");
			AddText($"\t.CompilerInputFiles = \"{action.inputFilePath}\"\n");
			AddText($"\t.CompilerOutputPath = \"{Path.GetDirectoryName(action.outputFilePath)}\"\n");

			if (action.usePCH)
			{
				if (usePCH_Windows)
				{
					//指定输入的pch文件头文件
					var pchHeanderFile = GetValueFromCommandArgs(ref action.noInputOutputPCHFileArgs, "/Yu", noQuotation: true, removeIt: true);
					var pchFile = GetValueFromCommandArgs(ref action.noInputOutputPCHFileArgs, "/Fp", noQuotation: true, removeIt: true);

					AddText($"\t.CompilerOptions = '/Fo\"%2\" \"%1\" /Yu\"{pchHeanderFile}\" /Fp\"{pchFile}\" {action.noInputOutputPCHFileArgs} '\n");

					PCHAction pchA = null;
					foreach (var item in pchCompileAction)
					{
						foreach (var produce in item.rawAction.ProducedItems)
						{
							if (produce.FullName == pchFile && item.isUsed == false)
							{
								pchA = item;
								item.isUsed = true;
								break;
							}
						}
					}
					if (pchA != null)
					{
						pchHeanderFile = GetValueFromCommandArgs(ref pchA.fastBuildPCHCompileArgs, $"/Yc", noQuotation: true, removeIt: true);
						pchFile = GetValueFromCommandArgs(ref pchA.fastBuildPCHCompileArgs, $"/Fp", noQuotation: true, removeIt: true);
						//GetValueFromCommandArgs(ref fastBuildPCHCompileArgs, $"/Fp", removeIt: true);

						AddText($"\t.PCHInputFile = '{pchA.inputFilePath}'\n");//.cpp
						AddText($"\t.PCHOutputFile = '{pchFile}'\n");//.pch
						AddText($"\t.PCHOptions = '/Yc\"{pchHeanderFile}\" /Fp\"%2\" \"%1\" /Fo\"{pchA.outputFilePath}\" {pchA.fastBuildPCHCompileArgs}'\n");
					}
				}
				else
				{
					//清理PCH
					var pchHeanderFile = GetValueFromCommandArgs(ref action.noInputOutputPCHFileArgs, "/Yu", noQuotation: true, removeIt: true);
					var pchFile = GetValueFromCommandArgs(ref action.noInputOutputPCHFileArgs, "/Fp", noQuotation: true, removeIt: true);
					AddText($"\t.CompilerOptions = '/Fo\"%2\" \"%1\" {action.noInputOutputPCHFileArgs} '\n");

				}
			}
			else
			{
				AddText($"\t.CompilerOptions = '/Fo\"%2\" \"%1\" {action.noInputOutputPCHFileArgs} '\n");

			}
			//cl-filter是在本地执行的
			if (action.useCLFilter)
			{
				// ** 注意这里的cl-filter是魔改的，可以读取stderr的头文件输出和stdout的预处理输出 **
				//添加头文件依赖输出
				AddText($"\t.Preprocessor = 'cl-filter'\n");
				//在本地运行就使用responsefile了,responsefile可以和命令混用，亲测，不用加/E msvc模式下面会自动加
				AddText($"\t.PreprocessorOptions = '{action.rawAction.CommandArguments}'\n");
			}

			AddText($"\t.AllowResponseFile = true \n");
			AddText($"\t.CompilerOutputExtension = '{action.outputFileExt}' \n");
			//AddText($"\t.CompilerOutputKeepBaseExtension = true \n");

			AddPreBuildDependenciesText(action.rawAction.PrerequisiteActions);
			AddText("}\n\n");

		}
		private void CreateBffFile_CompileAction_Clang(CodeCompileAction action, bool isClangPP)
		{
			//ISPCHeader -M -MF "xxx"
			//CPP -MD -MF "xxx"
			var noHeaderDepCmd = action.compilerArgs;
			var headerDepFilePath = GetValueFromCommandArgs(ref noHeaderDepCmd, "-MF", removeIt: true);
			var suc = GetValueFromCommandArgs(ref noHeaderDepCmd, "-MD", removeIt: true);
			var outputFmt = "";
			if (suc == null)
			{
				suc = GetValueFromCommandArgs(ref noHeaderDepCmd, "-M", removeIt: true);
				if (suc == null)
				{
					throw new Exception("不存在输出头文件依赖命令");
				}
				outputFmt = "-M";
			}
			else
			{
				outputFmt = "-MD";
			}

			var compilerName = "clang++";
			if (!isClangPP)
			{
				compilerName = "clang";
			}

			AddText($"ObjectList('{ActionToActionString(action.rawAction)}')\n{{\n");

			AddText($"\t.Compiler = '{compilerName}'\n");
			AddText($"\t.CompilerInputFiles = \"{action.inputFilePath}\"\n");
			AddText($"\t.CompilerOutputPath = \"{Path.GetDirectoryName(action.outputFilePath)}\"\n");

			if (action.usePCH)
			{
				//指定输入的pch文件头文件
				var pchFile = GetValueFromCommandArgs(ref noHeaderDepCmd, "-include-pch", noQuotation: true, removeIt: true);

				//由于clang不存在mscl的pch的头文件依赖输出的bug，所以可以留着用pch
				AddText($"\t.CompilerOptions = '-o \"%2\" \"%1\" -include-pch \"{pchFile}\" {noHeaderDepCmd} '\n");

				//PCH不能在这里声明，因为需要输出PCH的头文件依赖
				#region 旧声明PCH
				//PCHAction pchA = null;
				//foreach (var item in pchCompileAction)
				//{
				//	foreach (var produce in item.rawAction.ProducedItems)
				//	{
				//		if (produce.FullName == pchFile && item.isUsed != false)
				//		{
				//			pchA = item;
				//			item.isUsed = true;
				//			break;
				//		}
				//	}
				//}
				//            if (pchA != null)
				//            {
				//	AddText($"\t.PCHInputFile = '{pchA.inputFilePath}'");//.cpp
				//	AddText($"\t.PCHOutputFile = '{pchA.outputFilePath}'");//.gch
				//	AddText($"\t.PCHOptions = -o \"%2\" \"%1\" \"{pchA.fastBuildPCHCompileArgs}\"'");
				//}
				#endregion
			}
			else
			{
				AddText($"\t.CompilerOptions = '\"%1\" -o \"%2\" {action.noInputOutputPCHFileArgs} '\n");
			}


			AddText($"\t.Preprocessor = '{compilerName}'\n");
			AddText($"\t.PreprocessorOptions = '{action.rawAction.CommandArguments}'\n");


			AddText($"\t.CompilerOutputExtension = '{action.outputFileExt}' \n");
			//AddText($"\t.CompilerOutputKeepBaseExtension = true \n");

			AddPreBuildDependenciesText(action.rawAction.PrerequisiteActions);


			AddText("}\n\n");

		}

		private void CreateBffFile_CompileAction_GCC(CodeCompileAction action)
		{

		}

		public string GetCompilerPath(Action a)
		{
			var compilerPath = a.CommandPath.FullName;
			var compilerArgs = a.CommandArguments;

			string noCLFilterCmd = "";
			string CLFilterHeader = "";

			//解析出真正的命令
			if (compilerPath == "/bin/sh")
			{
				//-c | "xxx xxx"
				var splitArgs = compilerArgs.Split(new char[] { ' ' }, 1, StringSplitOptions.RemoveEmptyEntries);
				if (splitArgs.Length != 2 || !splitArgs[0].Trim().StartsWith("-"))
					throw new BuildException($"shell cmd invaild : {compilerArgs}");

				compilerArgs = UnpackQuotation(splitArgs[1].Trim());
			}
			//windows打包使用cl-filter进行执行编译器
			else if (Path.GetFileNameWithoutExtension(compilerPath) == "cl-filter")
			{
				//"-dependencies=D:\\_workspace\\_project\\ue4.26\\fastbuild_cpp\\Intermediate\\Build\\Win64\\UE4\\Development\\fastbuild_cpp\\fastbuild_cppHud.cpp.txt -compiler=D:\\software\\VS2019_IDE\\VC\\Tools\\MSVC\\14.28.29333\\bin\\HostX64\\x64\\cl.exe -- D:\\software\\VS2019_IDE\\VC\\Tools\\MSVC\\14.28.29333\\bin\\HostX64\\x64\\cl.exe  @\"D:\\_workspace\\_project\\ue4.26\\fastbuild_cpp\\Intermediate\\Build\\Win64\\UE4\\Development\\fastbuild_cpp\\fastbuild_cppHud.cpp.obj.response\" /showIncludes"
				//compilerPath = GetValueFromCommandArgs(ref compilerArgs, "-compiler=");
				//var compilerCommand = compilerArgs.Split(new string[] { " -- " }, 2, StringSplitOptions.RemoveEmptyEntries)[1];
				////不管空格了
				//compilerArgs = compilerCommand.Split("".ToCharArray(), 2, StringSplitOptions.RemoveEmptyEntries)[1];
				GetClFilterArgs(compilerArgs, out compilerPath, out noCLFilterCmd, out CLFilterHeader);

			}
			return compilerPath;
		}


		private void CreateBffFile_LinkAction(LinkAction a)
		{
			switch (a.linkCompiler)
			{
				case LinkCompiler.UEMSLinkFilter:
				case LinkCompiler.MSLink:
				case LinkCompiler.MSLib:
					CreateBffFile_LinkAction_MSVC(a);
					break;
				case LinkCompiler.clang:
					CreateBffFile_LinkAction_Clang(a, false);
					break;
				case LinkCompiler.clangPP:
					CreateBffFile_LinkAction_Clang(a, true);
					break;
				default:
					break;
			}
		}

		private void CreateBffFile_LinkAction_MSVC(LinkAction a)
		{
			IEnumerable<Action> dep = a.rawAction.PrerequisiteActions.Distinct();
			var noDepCmd = a.noLinkFilterCmd;
			List<Action> libDep = new List<Action>();


			#region 使用Exec本地编
			AddText($"Exec('{ActionToActionString(a.rawAction)}')\n{{ \n");
			AddText($"\t.ExecExecutable = '{a.compilerPath}'\n");
			//这个是带responsefile的
			AddText($"\t.ExecArguments = '{a.compilerArgs}'\n");
			//AddText($"\t.ExecInput = {a.compilerPath}\n");
			AddText($"\t.ExecOutput = '{a.outputLinkFile}'\n");

			AddPreBuildDependenciesText(dep);
			AddText($"}}\n\n");
			#endregion
			#region 使用DLL编 (这个不会分布式编)
			//if (!dep.Any())
			//{
			//	//throw new Exception($"链接的依赖不存在");
			//	//添加到本地运行
			//	localLink.Add(a.rawAction);
			//	return;

			//}
			//bool AddLibraries()
			//{
			//	bool added = false;
			//	foreach (var item in dep)
			//	{
			//		if (item.ActionType == ActionType.Compile && item.CommandDescription != "Resource" && !item.StatusDescription.Contains("PCH"))
			//		{
			//			var outputFile = GetOutPutFileInCompileAction(item);
			//			noDepCmd = noDepCmd.Replace($"\"{outputFile}\"", "");

			//			AddText($"\t\t\t\t'{ActionToActionString(item)}' ;{outputFile}\n");
			//			added = true;
			//		}
			//		else if (item.ActionType == ActionType.Link)
			//		{
			//			libDep.Add(item);
			//		}
			//	}



			//	return added;
			//}
			//switch (a.linkOutputType)
			//         {
			//             case LinkOutputType.StaticLib:
			//		//lib文件需要自己通过DLL间接构建？
			//		//RegistAliasNames(a.rawAction, a.outputLinkFile);
			//		AddText($"DLL('{ActionToActionString(a.rawAction)}')\n{{ \n");
			//		AddText($"\t.Linker = '{a.compilerPath}' \n");


			//		AddText("\t.Libraries = {\n");

			//		AddLibraries();

			//		AddText("\t\t\t}\n");

			//		AddText($"\t.LinkerOptions = '/Out:\"%2\" %1 {noDepCmd} ' \n");

			//		AddText($"\t.LinkerOutput = '{a.outputLinkFile}' \n");
			//		AddText($"\t.LinkerType = 'msvc' \n");

			//		break;
			//             case LinkOutputType.DynamicLib:
			//		AddText($"DLL('{ActionToActionString(a.rawAction)}')\n{{ \n");
			//		AddText($"\t.Linker = '{a.compilerPath}' \n");

			//		//Libraries 代表的是Objectlist或者Libraries的alias，不是引用的库
			//		AddText("\t.Libraries = {\n");
			//		bool added = AddLibraries();

			//		AddText("\t\t\t}\n");

			//		if (a.isUsingLinkFilter)
			//		{
			//			AddText($"\t.LinkerOptions = '{a.linkFilterHeader} /Out:\"%2\" %1 {noDepCmd}' \n");
			//		}
			//		else
			//		{
			//			AddText($"\t.LinkerOptions = '%1 /Out:\"%2\" {a.noLinkFilterCmd} ' \n");
			//		}

			//		AddText($"\t.LinkerOutput = '{a.outputLinkFile}' \n");
			//		AddText($"\t.LinkerType = 'msvc' \n");
			//		break;
			//             case LinkOutputType.Exec:
			//                 AddText($"Executable('{ActionToActionString(a.rawAction)}')\n{{ \n");
			//                 AddText($"\t.Linker = '{a.compilerPath}' \n");

			//		AddText("\t.Libraries = {\n");
			//		AddLibraries();

			//		AddText("\t\t\t}\n");

			//                 if (a.isUsingLinkFilter)
			//                 {
			//			AddText($"\t.LinkerOptions = '{a.linkFilterHeader} /Out:\"%2\" %1 {a.noLinkFilterCmd}'\n");
			//		}
			//		else
			//                 {
			//			AddText($"\t.LinkerOptions = '/Out:\"%2\" %1 {a.noLinkFilterCmd} ' \n");
			//		}
			//		AddText($"\t.LinkerOutput = '{a.outputLinkFile}' \n");
			//                 AddText($"\t.LinkerType = 'msvc' \n");

			//                 break;
			//             default:
			//                 break;
			//         }

			//AddPreBuildDependenciesText(libDep);
			//AddText($"}}\n\n");
			#endregion
		}

		private void CreateBffFile_LinkAction_Clang(LinkAction a, bool isClangPP)
		{
			#region 使用Exec本地编
			AddText($"Exec('{ActionToActionString(a.rawAction)}')\n{{ \n");
			AddText($"\t.ExecExecutable = '{a.compilerPath}'\n");
			//这个是带responsefile的
			AddText($"\t.ExecArguments = '{a.compilerArgs}'\n");
			//AddText($"\t.ExecInput = {a.compilerPath}\n");
			AddText($"\t.ExecOutput = '{a.outputLinkFile}'\n");

			AddPreBuildDependenciesText(a.rawAction.PrerequisiteActions);
			AddText($"}}\n\n");
			#endregion
		}
		private void CreateBffFile_ExecAction(Action a, string outputFile)
		{
			AddText($"Exec('{ActionToActionString(a)}')\n{{\n");
			AddText($"\t.ExecExecutable = '{a.CommandPath}'\n");
			AddText($"\t.ExecArguments = '{a.CommandArguments}'\n");
			AddText($"\t.ExecOutput = '{outputFile}'\n");
			AddPreBuildDependenciesText(a.PrerequisiteActions);
			AddText("}\n\n");
		}
		private void CreateBffFile_ExecAction_Cache(Action a, string compilerAliasName, string cmdArgs, string inputFile, string outputFile, string fileExt)
		{
			AddText($"ObjectList('{ActionToActionString(a)}')\n{{\n");
			AddText($"\t.Compiler = '{compilerAliasName}'\n");
			AddText($"\t.CompilerInputFiles = '{inputFile}'\n");
			AddText($"\t.CompilerOutputPath = '{Path.GetDirectoryName(outputFile)}'\n");
			AddText($"\t.CompilerOptions = '{cmdArgs}'\n");
			AddText($"\t.CompilerOutputExtension = '{fileExt}'\n");
			AddText($"\t.ExecutableRootPath  = '{Directory.GetCurrentDirectory()}'\n");

			AddText($"\t.AllowDistribution = false\n");
			AddPreBuildDependenciesText(a.PrerequisiteActions);
			AddText("}\n\n");
		}

		class ExtAction
		{
			public Action rawAction;
			public bool useShell;
			public string compilerPath;
			public string compilerArgs;
			public string inputFilePath;
			public string outputFilePath;

			public string noInputOutputFileArgs;


			public string RawCommandArgs
			{
				get
				{
					return rawAction.CommandArguments;
				}
			}

			public ExtAction(Action action)
			{
				this.rawAction = action;
				compilerPath = action.CommandPath.FullName;
				compilerArgs = action.CommandArguments;



			}
			protected string GetResponeseFilePath(string args)
			{
				string value = GetValueFromCommandArgs(ref args, "@", removeIt: true);
				var responseFilePath = "";
				if (!string.IsNullOrEmpty(value))
				{
					responseFilePath = UnpackQuotation(value);
				}
				if (string.IsNullOrEmpty(responseFilePath))
				{
					Log.TraceInformation($"READ RESPONSEFILE = null ,args = {args}");
					return "";
				}
				return responseFilePath;
			}

			protected string ReadResponeseFile(string args)
			{
				var responseFilePath = GetResponeseFilePath(args);
				if (!string.IsNullOrEmpty(responseFilePath))
				{
					//Log.TraceInformation($"READ RESPONSEFILE = {responseFilePath}");
					var content = File.ReadAllText(responseFilePath);
					//MSVC
					content = content.Replace(Environment.NewLine, " ").Trim();
					return content;
				}
				return null;

			}
		}

		class PCHAction : ExtAction
		{
			public CodeCompiler codeCompiler;
			public string fastBuildPCHCompileArgs;
			public bool isUsed = false;

			public string noCLFilterCmd = "";
			public string CLFilterHeader = "";
			public string respFile = "";

			public PCHAction(Action action) : base(action)
			{
				respFile = GetResponeseFilePath(RawCommandArgs);
				var respCmd = ReadResponeseFile(action.CommandArguments);
				compilerArgs = rawAction.CommandArguments.Replace($"@\"{respFile}\"", respCmd);

				string compilerName = Path.GetFileNameWithoutExtension(compilerPath);
				switch (compilerName)
				{
					case "cl":
					case "icl":
					case "cl-fitler":
						codeCompiler = CodeCompiler.MSCL;
						break;
					case "clang++":
						codeCompiler = CodeCompiler.ClangPP;
						break;
					case "clang":
						codeCompiler = CodeCompiler.Clang;
						break;
					case "gcc":
					case "g++":
					case "dcc":
						codeCompiler = CodeCompiler.GCC;
						break;
					default:
						break;
				}
				if (codeCompiler == CodeCompiler.MSCL)
				{
					GetClFilterArgs(compilerArgs, out compilerPath, out noCLFilterCmd, out CLFilterHeader);
				}
				else
				{
					noCLFilterCmd = compilerArgs;
				}

				//列出pch文件
				foreach (var produce in action.ProducedItems)
				{
					var extFlag = ".gch"; //可能标志-x c++-header/c-header

					if (codeCompiler == CodeCompiler.MSCL)
					{
						extFlag = ".obj";
					}
					if (produce.Name.EndsWith(extFlag))
					{
						PCHFilePaths.Add(produce.FullName);
					}
				}



				if (codeCompiler == CodeCompiler.MSCL)
				{
					var filenameWithoutExtension = Path.GetFileNameWithoutExtension(action.PrerequisiteItems[0].FullName);
					inputFilePath = Path.Combine(Path.GetDirectoryName(action.PrerequisiteItems[0].FullName), filenameWithoutExtension + ".cpp");
					//outputFilePath = Path.Combine(Path.GetDirectoryName(action.PrerequisiteItems[0].FullName), filenameWithoutExtension + ".h.obj");
					outputFilePath = action.ProducedItems[1].FullName;//.obj

				}
				else
				{
					foreach (var item in action.PrerequisiteItems)
					{
						var extension = Path.GetExtension(item.FullName);
						if (extension == ".h")
						{
							inputFilePath = item.FullName.Replace("\\", "/");
							break;
						}

					}
					foreach (var item in action.ProducedItems)
					{
						var extension = Path.GetExtension(item.FullName);
						if (extension == ".gch")
						{
							outputFilePath = item.FullName.Replace("\\", "/");
							break;
						}
					}
				}

				Log.TraceInformation($"inputFilePath={inputFilePath}");
				Log.TraceInformation($"outputFilePath={outputFilePath}");


				noInputOutputFileArgs = noCLFilterCmd;
				if (codeCompiler == CodeCompiler.MSCL)
				{
					GetValueFromCommandArgs(ref noInputOutputFileArgs, $"\"{inputFilePath}\"", removeIt: true);
					GetValueFromCommandArgs(ref noInputOutputFileArgs, $"/Fo", removeIt: true);
					fastBuildPCHCompileArgs = noInputOutputFileArgs;
					//pch
					//GetValueFromCommandArgs(ref fastBuildPCHCompileArgs, $"/Yc", removeIt: true);
					//GetValueFromCommandArgs(ref fastBuildPCHCompileArgs, $"/Fp", removeIt: true);

				}
				else
				{
					GetValueFromCommandArgs(ref noInputOutputFileArgs, $"\"{inputFilePath}\"", removeIt: true);
					GetValueFromCommandArgs(ref noInputOutputFileArgs, $"-o", removeIt: true);
					//throw new Exception("非mscl未实现");
					fastBuildPCHCompileArgs = noInputOutputFileArgs;
				}

				//如果不用pch，需要清理原action的产物
				//rawAction.ProducedItems.Clear();

			}
		}
		class RCAction : ExtAction
		{
			public ResCompiler resCompiler;

			public RCAction(Action action) : base(action)
			{
				string compilerName = Path.GetFileNameWithoutExtension(compilerPath);
				switch (compilerName)
				{
					case "rc":
						resCompiler = ResCompiler.MSRC;
						break;
					default:
						break;
				}
			}
		}
		class LinkAction : ExtAction
		{
			public bool isFinish = false;
			public bool isUsingLinkFilter = false;
			/// <summary>
			/// -- 后面带编译器路径
			/// </summary>
			public string linkFilterHeader = "";
			/// <summary>
			/// 没有编译器路径的开头
			/// </summary>
			public string noLinkFilterCmd = "";
			public string linkerPath = "";
			public bool useResponseFile = false;
			public string outputLinkFile;
			public List<string> inputLinkFiles;


			public LinkOutputType linkOutputType;
			public LinkCompiler linkCompiler;

			public string responseFilePath;


			public LinkAction(Action action, LinkCompiler linkCompiler = LinkCompiler.MSLink) : base(action)
			{
				this.linkCompiler = linkCompiler;
				inputLinkFiles = new List<string>(8);

				//TODO link-filter的处理
				//link-filter作用
				//This program is designed to execute the Visual C++linker(link.exe) and restart if it sees a spurious "Unexpected PDB error; OK (0)"
				//message in the output.
				//TODO 失败后退出码是1，需要的是重新进行一次链接
				//TODO 在link-filter中间加3次重试

				//string[] SpecialLinkerOptions = IsApple() ? new string[] { "-o" } : new string[] { "/OUT:", "@", "-o" };
				// TODO shell
				//var respContent = ReadResponeseFile(compilerArgs);
				responseFilePath = GetResponeseFilePath(compilerArgs);
				string respCmd = "";
				string respContent = "";
				string[] lines = null;
				if (!string.IsNullOrEmpty(responseFilePath))
				{
					respContent = File.ReadAllText(responseFilePath);
					lines = File.ReadAllText(responseFilePath).Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
					//MSVC
					respCmd = string.Join(" ", lines);
				}

				if (!string.IsNullOrEmpty(respCmd))
				{
					useResponseFile = true;
				}
				if (useResponseFile)
				{
					noLinkFilterCmd = rawAction.CommandArguments.Replace($"@\"{responseFilePath}\"", respCmd);
				}
				else
				{
					noLinkFilterCmd = compilerArgs;
				}
				switch (linkCompiler)
				{
					case LinkCompiler.UEMSLinkFilter:
						isUsingLinkFilter = true;
						var tmp = compilerArgs.Split(new string[] { "-- " }, StringSplitOptions.None);
						linkerPath = GetValueFromCommandArgs(ref compilerArgs, "--", noQuotation: true);
						linkFilterHeader = $"{tmp[0]} -- \"{linkerPath}\"";
						if (!useResponseFile)
						{
							noLinkFilterCmd = tmp[1];
							GetValueFromCommandArgs(ref noLinkFilterCmd, linkerPath, removeIt: true);
						}
						linkOutputType = LinkOutputType.DynamicLib;
						MSVCIOFilesInit(lines);
						break;
					case LinkCompiler.MSLink:
						linkerPath = compilerPath;
						string val = GetValueFromCommandArgs(ref noLinkFilterCmd, "/DLL:");
						if (val == null)
						{
							linkOutputType = LinkOutputType.DynamicLib;
						}
						else
						{
							linkOutputType = LinkOutputType.Exec;
						}
						MSVCIOFilesInit(lines);
						break;
					case LinkCompiler.MSLib:
						linkOutputType = LinkOutputType.StaticLib;
						MSVCIOFilesInit(lines);

						break;
					case LinkCompiler.clang:
					case LinkCompiler.clangPP:
						//-static是可执行文件标识？
						var suc = GetValueFromCommandArgs(ref noLinkFilterCmd, "-shared");
						if (suc != null)
						{
							linkOutputType = LinkOutputType.DynamicLib;
						}
						else
						{
							linkOutputType = LinkOutputType.StaticLib;
						}
						var outputFile = GetValueFromCommandArgs(ref noLinkFilterCmd, "-o", noQuotation: true, removeIt: true);

						outputLinkFile = outputFile;
						break;
					default:
						break;
				}
				if (string.IsNullOrEmpty(outputLinkFile))
					throw new Exception($"{linkCompiler.ToString()}输出文件为空");



				#region 移除pch

				//因为每个库都带pch，pch无法分发出去只能本地编译，所以要移除pch
				//由于是基于预处理的，所以每个obj文件都是包含完整的编译信息，所以有无pch都不会影响最后的生成
				//目前引擎是生成pch，所以link会存在pch，如果引擎通过fastbuild重编出无pch的结构，则可以
				//将link阶段全部分发出去(分发个p，fastbuild本身就不分发link阶段)
				//remove pch

				//D:\_workspace\_project\A8\Program\Client\NextGenGame\Intermediate\Build\Win64\HitBoxMakerBlueprint\Development\Engine\SharedPCH.Engine.ShadowErrors.NoUndef.h.obj
				//D:\_workspace\_project\A8\Program\Client\NextGenGame\Intermediate\Build\Win64\HitBoxMakerBlueprint\Development\Engine

				//bool RemoveRun(FileItem file)
				//{
				//    foreach (var item in PCHFilePaths)
				//    {
				//        if (file.FullName == item)
				//            return true;
				//    }
				//    return false;
				//}

				//action.PrerequisiteItems.RemoveAll(RemoveRun);
				//var tmp = action.CommandArguments;

				//var responsefilepath = GetValueFromCommandArgs(ref tmp, "@", noQuotation: true);
				//if (!string.IsNullOrEmpty(responsefilepath))
				//{
				//    var responsefileContent = File.ReadAllText(responsefilepath);
				//    string responsefileNewContent = responsefileContent;
				//    foreach (var PCHFilePath in PCHFilePaths)
				//    {
				//        responsefileNewContent = responsefileNewContent.Replace($"\"{PCHFilePath}\"\r\n", "");
				//    }
				//    File.WriteAllText(responsefilepath, responsefileNewContent);
				//}
				//else
				//{
				//    foreach (var PCHFilePath in PCHFilePaths)
				//    {
				//        GetValueFromCommandArgs(ref compilerArgs, PCHFilePath, removeIt: true);
				//    }
				//}
				#endregion
			}
			private void MSVCIOFilesInit(string[] lines)
			{
				outputLinkFile = GetValueFromCommandArgs(ref noLinkFilterCmd, "/OUT:", noQuotation: true, removeIt: true);

				foreach (var line in lines)
				{
					//暂时这样获取输入文件
					if (line.StartsWith("\""))
					{
						inputLinkFiles.Add(UnpackQuotation(line));
					}
				}
			}
		}

		static void GetClFilterArgs(string args, out string compilerPath, out string noCLFilterCmd, out string CLFilterHeader)
		{
			compilerPath = GetValueFromCommandArgs(ref args, "-compiler=", noQuotation: true);
			var tmp = args.Split(new string[] { " -- " }, 2, StringSplitOptions.RemoveEmptyEntries);
			var compilerCommand = tmp[1];
			noCLFilterCmd = compilerCommand.Replace($"\"{compilerPath}\"", "");
			noCLFilterCmd = noCLFilterCmd.Replace($"{compilerPath}", "");

			CLFilterHeader = $"{tmp[0]} -- \"{compilerPath}\"";
		}
		class CodeCompileAction : ExtAction
		{
			public bool useCLFilter;
			public CodeCompiler codeCompiler;
			public string noInputOutputPCHFileArgs;
			public string outputFileExt;


			public bool usePCH = false;

			public string noCLFilterCmd = "";
			public string CLFilterHeader = "";

			public CodeCompileAction(Action action) : base(action)
			{
				var respFile = GetResponeseFilePath(action.CommandArguments);
				var respCmd = ReadResponeseFile(action.CommandArguments);
				compilerArgs = rawAction.CommandArguments.Replace($"@\"{respFile}\"", respCmd);

				//解析出真正的命令
				if (compilerPath == "/bin/sh")
				{
					useShell = true;
					//-c | "xxx xxx"
					var splitArgs = compilerArgs.Split(new char[] { ' ' }, 1, StringSplitOptions.RemoveEmptyEntries);
					if (splitArgs.Length != 2 || !splitArgs[0].Trim().StartsWith("-"))
						throw new BuildException($"shell cmd invaild : {compilerArgs}");

					compilerArgs = UnpackQuotation(splitArgs[1].Trim());
				}
				//windows打包使用cl-filter进行执行编译器
				else if (Path.GetFileNameWithoutExtension(compilerPath) == "cl-filter")
				{
					useCLFilter = true;
					//"-dependencies=D:\\_workspace\\_project\\ue4.26\\fastbuild_cpp\\Intermediate\\Build\\Win64\\UE4\\Development\\fastbuild_cpp\\fastbuild_cppHud.cpp.txt -compiler=D:\\software\\VS2019_IDE\\VC\\Tools\\MSVC\\14.28.29333\\bin\\HostX64\\x64\\cl.exe -- D:\\software\\VS2019_IDE\\VC\\Tools\\MSVC\\14.28.29333\\bin\\HostX64\\x64\\cl.exe  @\"D:\\_workspace\\_project\\ue4.26\\fastbuild_cpp\\Intermediate\\Build\\Win64\\UE4\\Development\\fastbuild_cpp\\fastbuild_cppHud.cpp.obj.response\" /showIncludes"
					GetClFilterArgs(compilerArgs, out compilerPath, out noCLFilterCmd, out CLFilterHeader);

				}
				else
				{
					noCLFilterCmd = RawCommandArgs;
				}

				string compilerName = Path.GetFileNameWithoutExtension(compilerPath);
				switch (compilerName)
				{
					case "cl":
					case "icl":
					case "cl-filter":
						codeCompiler = CodeCompiler.MSCL;
						break;
					case "clang++":
						codeCompiler = CodeCompiler.ClangPP;
						break;
					case "clang":
						codeCompiler = CodeCompiler.Clang;
						break;
					case "gcc":
					case "g++":
					case "dcc":
						codeCompiler = CodeCompiler.GCC;
						break;
					default:
						break;
				}

				string n_noCLFilterCmd = ReadResponeseFile(noCLFilterCmd);
				if (!string.IsNullOrEmpty(n_noCLFilterCmd))
				{
					noCLFilterCmd = n_noCLFilterCmd;
				}

				inputFilePath = GetInPutFileInCompileAction(action);
				outputFilePath = GetOutPutFileInCompileAction(action);

				if (string.IsNullOrEmpty(inputFilePath))
				{
					throw new Exception("输入不应该为空");
				}
				if (string.IsNullOrEmpty(outputFilePath))
				{
					throw new Exception("输出不应该为空");
				}

				var inputFileName = Path.GetFileName(inputFilePath); //xxx.cpp
				var outputFileName = Path.GetFileName(outputFilePath); // xxx.cppa7.o

				var inputFileExt = Path.GetExtension(inputFilePath); //.cpp
				outputFileExt = outputFileName.Replace(inputFileName, inputFileExt); //.cppa7.o



				Log.TraceInformation($"inputFilePath={inputFilePath}");
				Log.TraceInformation($"outputFilePath={outputFilePath}");

				noInputOutputFileArgs = noCLFilterCmd;
				if (codeCompiler == CodeCompiler.MSCL)
				{
					Log.TraceInformation($"=======================================");
					GetValueFromCommandArgs(ref noInputOutputFileArgs, $"\"{inputFilePath}\"", removeIt: true);
					GetValueFromCommandArgs(ref noInputOutputFileArgs, $"/Fo", removeIt: true);
				}
				else
				{
					GetValueFromCommandArgs(ref noInputOutputFileArgs, $"\"{inputFilePath.Replace('\\', '/')}\"", removeIt: true);
					GetValueFromCommandArgs(ref noInputOutputFileArgs, $"-o", removeIt: true);
				}


				//清理pch
				if (codeCompiler == CodeCompiler.MSCL)
				{
					noInputOutputPCHFileArgs = noInputOutputFileArgs;
					//指定输入的pch文件
					var flag = GetValueFromCommandArgs(ref noInputOutputPCHFileArgs, "/Yu", removeIt: false);
					if (!string.IsNullOrEmpty(flag))
					{
						usePCH = true;
					}
					//指定输入的pch文件头文件
					//GetValueFromCommandArgs(ref noInputOutputPCHFileArgs, "/Fp", removeIt: true);
				}
				else
				{
					noInputOutputPCHFileArgs = noInputOutputFileArgs;
					var flag = GetValueFromCommandArgs(ref noInputOutputPCHFileArgs, "-include-pch", removeIt: true);
					if (!string.IsNullOrEmpty(flag))
					{
						usePCH = true;
					}
				}
			}
		}


		#region 通用方法
		static HashSet<string> codeMaybeInputFileExt = new HashSet<string>()
				{
					".cpp",".cc",".cxx",// c++
					".c",".C", // c
					".mm",".m", // oc
					".S",".s",".asm" // 汇编
				};
		static HashSet<string> codeMaybeOutputFileExt = new HashSet<string>()
				{
					".o", // Clang/gcc
					".obj" // MSCL
				};


		private static string GetInPutFileInCompileAction(Action a)
		{
			var inputFilePath = "";

			foreach (var item in a.PrerequisiteItems)
			{
				var fileExt = Path.GetExtension(item.Name);
				if (codeMaybeInputFileExt.Contains(fileExt))
				{
					inputFilePath = item.FullName;
					break;
				}
			}
			return inputFilePath;

		}
		private static string GetOutPutFileInCompileAction(Action a)
		{
			var outputFilePath = "";
			foreach (var item in a.ProducedItems)
			{
				var fileExt = Path.GetExtension(item.Name);
				if (codeMaybeOutputFileExt.Contains(fileExt))
				{
					outputFilePath = item.FullName;
					break;
				}
			}
			return outputFilePath;
		}
		private static bool IsCommandOptionFlag(char c)
		{
			return c == '/' || c == '-';
		}
		public static string GetValueFromCommandArgs(ref string args, string key, bool noQuotation = false, bool removeIt = false)
		{

			args = args.Trim();
			int index = args.IndexOf(key);
			if (index < 0)
				return null;
			if (index - 1 > 0)
			{
				if (args[index - 1] != ' ')
				{
					index = args.IndexOf(" " + key);
					index++;
				}
			}



			string val = null;
			bool isUseSpaceSplitKeyValue = false;

			//代表key是args的末尾
			if (index + key.Length > args.Length)
			{
				val = null;
			}
			//key之后是空格
			else if (args[index + key.Length] == ' ')
			{
				isUseSpaceSplitKeyValue = true;
				//混合两种操作符，应该不会出问题
				if (IsCommandOptionFlag(args[index + key.Length + 1]))
				{
					//没有值，也就代表不存在key和value分割
					isUseSpaceSplitKeyValue = false;
					val = "";
				}
				//剩下的就是值，取出来后还得去除"
				else
				{
					val = GetValueFromCommandArgs_Internal_NoCheck(args, key, index, isUseSpaceSplitKeyValue);
				}
			}
			//值和操作符一起的，例如-opt=xxx --opt=xxx -I"xxxxx"
			else
			{
				isUseSpaceSplitKeyValue = false;
				val = GetValueFromCommandArgs_Internal_NoCheck(args, key, index, isUseSpaceSplitKeyValue);
			}

			if (removeIt)
			{
				//只有key操作符
				int valLen = 0;
				if (!string.IsNullOrEmpty(val))
					valLen = val.Length;

				//+1是为了移除末尾空格
				int len = key.Length + valLen + 1;
				//+1是为了处理key和value之间的空格
				int count = isUseSpaceSplitKeyValue ? len + 1 : len;
				int remainLen = args.Length - index;
				count = Math.Min(remainLen, count);
				//先这样写
				args = args.Remove(index, count).Trim();

			}


			if (noQuotation)
			{
				val = UnpackQuotation(val);
			}
			return val;

		}
		private static string GetValueFromCommandArgs_Internal_NoCheck(string args, string key, int keyindex, bool isUseSpaceSplitKeyValue)
		{
			StringBuilder valSB = new StringBuilder("");
			int startIndex = keyindex + key.Length;
			if (isUseSpaceSplitKeyValue)
				startIndex += 1;
			bool hasQuote = args[startIndex] == '\"';
			bool isQuotedState = false;
			int endIndex = startIndex;
			for (; endIndex < args.Length; endIndex++)
			{
				if (!isQuotedState && args[endIndex] == ' ')
					break;

				valSB.Append(args[endIndex]);

				if (args[endIndex] == '\"')
				{
					isQuotedState = !isQuotedState;
				}
				if (hasQuote == true && isQuotedState == false)
				{
					break;
				}

			}
			return valSB.ToString();
		}
		/// <summary>
		/// 去除双引号
		/// </summary>
		/// <param name="str"></param>
		/// <returns></returns>
		public static string UnpackQuotation(string str)
		{
			if (str == null)
			{
				return null;
			}
			StringBuilder strSB = new StringBuilder(str);
			if (!string.IsNullOrEmpty(str) && strSB[0] == '\"' && strSB[strSB.Length - 1] == '\"')
			{
				strSB.Remove(strSB.Length - 1, 1);
				strSB.Remove(0, 1);
			}
			return strSB.ToString();
		}
		#endregion


		/// <summary>
		/// clui.dll是语言包，需要返回所有可能的语言包防止出错
		/// </summary>
		/// <param name="path"></param>
		/// <param name="langID">指定语言id</param>
		/// <returns></returns>
		private FileReference GetCluidll(string path, int langID)
		{
			List<FileReference> cluiPaths = new List<FileReference>();

			var cluiPath = Path.Combine(path, langID.ToString(), "clui.dll");
			if (!File.Exists(cluiPath))
			{
				return null;
			}
			return new FileReference(cluiPath);
		}
		private bool CreateBffFile_Windows()
		{


			var VCEnv = VCEnvironment.Create(WindowsPlatform.GetDefaultCompiler(null), UnrealTargetPlatform.Win64, WindowsArchitecture.x64, null, null, null);
			if (VCEnv == null)
			{
				Log.TraceError("Visual Studio Env Not Found");
				throw new BuildException("Visual Studio Env Not Found");
			}
			// Copy environment into a case-insensitive dictionary for easier key lookups
			Dictionary<string, string> envVars = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
			foreach (DictionaryEntry entry in Environment.GetEnvironmentVariables())
			{
				envVars[(string)entry.Key] = (string)entry.Value;
			}

			if (envVars.ContainsKey("CommonProgramFiles"))
			{
				AddText("#import CommonProgramFiles\n");
			}
			//DirectX SDK
			if (envVars.ContainsKey("DXSDK_DIR"))
			{
				AddText("#import DXSDK_DIR\n");
			}
			////Xbox One SDK
			//if (envVars.ContainsKey("DurangoXDK"))
			//{
			//	AddText("#import DurangoXDK\n");
			//}

			DirectoryReference CLFilterDirectory = DirectoryReference.Combine(UnrealBuildTool.EngineDirectory, "Build", "Windows", "cl-filter");

			string platformVersionNumber = "VSVersionUnknown";
			AddText($".WindowsSDKBasePath = '{VCEnv.WindowsSdkDir}'\n");
			AddText($".Root = '{VCEnv.GetToolPath()}'\n");
			AddText($".CLFilterRoot = '{CLFilterDirectory.FullName}'\n");

			AddText($"Compiler('UEResourceCompiler') \n{{\n");
			switch (VCEnv.Compiler)
			{
				case WindowsCompiler.VisualStudio2017:
				case WindowsCompiler.VisualStudio2019:
					// For now we are working with the 140 version, might need to change to 141 or 150 depending on the version of the Toolchain you chose
					// to install
					platformVersionNumber = "140";
					AddText($"\t.Executable = '$WindowsSDKBasePath$\\bin\\{VCEnv.WindowsSdkVersion}\\x64\\rc.exe'\n");
					break;

				default:
					string exceptionString = "Error: Unsupported Visual Studio Version.";
					Log.TraceError(exceptionString);
					throw new BuildException(exceptionString);
			}

			AddText($"\t.CompilerFamily  = 'custom'\n");
			AddText($"}}\n\n");

			AddText("Compiler('msvc') \n{\n");
			bool noCLFilterRemote = true;
			if (noCLFilterRemote)
			{
				AddText($"\t.Executable = '$Root$\\cl.exe'\n");
				AddText($"\t.ExtraFiles =\n\t{{\n");
			}
			else
			{
				AddText($"\t.Executable = '$CLFilterRoot$\\cl-filter.exe'\n");
				AddText($"\t.ExtraFiles =\n\t{{\n");
				AddText($"\t\t'$Root$\\cl.exe'\n");
			}
			AddText($"\t\t'$Root$\\c1.dll'\n");
			AddText($"\t\t'$Root$\\c1xx.dll'\n");
			AddText($"\t\t'$Root$\\c2.dll'\n");

			//发起者必须有VS环境
			var langID = GetSystemDefaultLCID();
			var cluiDllPath = GetCluidll(VCEnv.GetToolPath().FullName, langID);
			if (cluiDllPath == null)
			{
				langID = 1033;
				cluiDllPath = GetCluidll(VCEnv.GetToolPath().FullName, langID);//1033是英文语言id
			}

			if (cluiDllPath == null)
				throw new BuildException($"clui.dll NOT FIND in {VCEnv.GetToolPath().FullName}");


			// FASTBuild only preserves the directory structure of compiler files for files in the same directory or sub-directories of the primary executable
			// Since our primary executable is cl-filter.exe and we need clui.dll in a sub-directory on the worker, we need to copy it to cl-filter's subdir
			Directory.CreateDirectory(Path.Combine(CLFilterDirectory.FullName, langID.ToString()));
			File.Copy(cluiDllPath.FullName, Path.Combine(CLFilterDirectory.FullName, langID.ToString(), "clui.dll"), true);
			//cl-filter会尝试所有语言包，然而fastbuild不允许重名文件存在
			if (noCLFilterRemote)
			{
				AddText($"\t\t'$Root$\\{langID.ToString()}\\clui.dll'\n");
			}
			else
			{
				AddText($"\t\t'$CLFilterRoot$\\{langID.ToString()}\\clui.dll'\n");
			}
			AddText("\t\t'$Root$\\mspdbsrv.exe'\n");
			AddText("\t\t'$Root$\\mspdbcore.dll'\n");
			AddText($"\t\t'$Root$\\mspft{platformVersionNumber}.dll'\n");
			AddText($"\t\t'$Root$\\msobj{platformVersionNumber}.dll'\n");
			AddText($"\t\t'$Root$\\mspdb{platformVersionNumber}.dll'\n");

			List<String> PotentialMSVCRedistPaths = new List<String>(Directory.EnumerateDirectories(string.Format("{0}\\Redist\\MSVC", VCEnv.GetVCInstallDirectory())));
			string PrefferedMSVCRedistPath = null;
			string FinalMSVCRedistPath = "";

			if (MsvcCRTRedistVersion.Length > 0)
			{
				PrefferedMSVCRedistPath = PotentialMSVCRedistPaths.Find(
					delegate (String str)
					{
						return str.Contains(MsvcCRTRedistVersion);
					});
			}

			if (PrefferedMSVCRedistPath == null)
			{
				PrefferedMSVCRedistPath = PotentialMSVCRedistPaths[PotentialMSVCRedistPaths.Count - 2];

				if (MsvcCRTRedistVersion.Length > 0)
				{
					Log.TraceInformation("Couldn't find redist path for given MsvcCRTRedistVersion {" + MsvcCRTRedistVersion.ToString()
					+ "} (in BuildConfiguration.xml). \n\t...Using this path instead: {" + PrefferedMSVCRedistPath.ToString() + "}");
				}
				else
				{
					Log.TraceInformation("Using path : {" + PrefferedMSVCRedistPath.ToString() + "} for vccorlib_.dll (MSVC redist)..." +
						"\n\t...Add an entry for MsvcCRTRedistVersion in BuildConfiguration.xml to specify a version number");
				}

			}

			PotentialMSVCRedistPaths = new List<String>(Directory.EnumerateDirectories(string.Format("{0}\\{1}", PrefferedMSVCRedistPath, VCEnv.Architecture)));

			FinalMSVCRedistPath = PotentialMSVCRedistPaths.Find(
			delegate (String str)
			{
				return str.Contains(".CRT");
			});

			if (FinalMSVCRedistPath.Length <= 0)
			{
				FinalMSVCRedistPath = PrefferedMSVCRedistPath;
			}

			void AddOtherDep()
			{
				if (VCEnv.Compiler == WindowsCompiler.VisualStudio2017)
				{
					//VS 2017 is really confusing in terms of version numbers and paths so these values might need to be modified depending on what version of the tool chain you
					// chose to install.
					AddText(string.Format("\t\t'{0}\\Redist\\MSVC\\14.16.27012\\{1}\\Microsoft.VC141.CRT\\msvcp{2}.dll'\n", VCEnv.GetVCInstallDirectory(), VCEnv.Architecture, platformVersionNumber));
					AddText(string.Format("\t\t'{0}\\Redist\\MSVC\\14.16.27012\\{1}\\Microsoft.VC141.CRT\\vccorlib{2}.dll'\n", VCEnv.GetVCInstallDirectory(), VCEnv.Architecture, platformVersionNumber));
				}
				else // if (VCEnv.Compiler == WindowsCompiler.VisualStudio2019)
				{
					AddText($"\t\t'$Root$\\msvcp{platformVersionNumber}.dll'\n");
					AddText(string.Format("\t\t'{0}\\vccorlib{1}.dll'\n", FinalMSVCRedistPath, platformVersionNumber));
					AddText($"\t\t'$Root$\\tbbmalloc.dll'\n");

					//AddText(string.Format("\t\t'{0}/Redist/MSVC/{1}/x64/Microsoft.VC141.CRT/vccorlib{2}.dll'\n", VCEnv.GetVCInstallDirectory(), VCEnv.ToolChainVersion, platformVersionNumber));
				}
			}
			AddOtherDep();

			AddText("\t}\n"); //End extra files

			AddText($"\t.CompilerFamily = 'msvc'\n");
			AddText("}\n\n"); //End compiler





			AddText("Compiler('cl-filter') \n{\n");
			AddText($"\t.Executable = '$CLFilterRoot$\\cl-filter.exe'\n");
			AddText($"\t.ExtraFiles =\n\t{{\n");
			AddText($"\t\t'$Root$\\cl.exe'\n");
			AddText($"\t\t'$Root$\\c1.dll'\n");
			AddText($"\t\t'$Root$\\c1xx.dll'\n");
			AddText($"\t\t'$Root$\\c2.dll'\n");
			AddText($"\t\t'$CLFilterRoot$\\{langID.ToString()}\\clui.dll'\n");
			AddText("\t\t'$Root$\\mspdbsrv.exe'\n");
			AddText("\t\t'$Root$\\mspdbcore.dll'\n");
			AddText($"\t\t'$Root$\\mspft{platformVersionNumber}.dll'\n");
			AddText($"\t\t'$Root$\\msobj{platformVersionNumber}.dll'\n");
			AddText($"\t\t'$Root$\\mspdb{platformVersionNumber}.dll'\n");
			AddOtherDep();
			AddText("\t}\n"); //End extra files
			AddText($"\t.CompilerFamily = 'msvc'\n");
			AddText("}\n\n"); //End compiler



			List<string> envs = new List<string>();
			envs.Add(string.Format("\t\t\"PATH={0}\\Common7\\IDE\\;{1};{2}\",\n", VCEnv.GetVCInstallDirectory(), VCEnv.GetToolPath(), VCEnv.GetWindowsSDKToolPath()));

			if (envVars.ContainsKey("TMP"))
				envs.Add($"\t\t\"TMP={envVars["TMP"]}\",\n");

			if (envVars.ContainsKey("SystemRoot"))
				envs.Add($"\t\t\"SystemRoot={envVars["SystemRoot"]}\",\n");

			if (envVars.ContainsKey("INCLUDE"))
				envs.Add($"\t\t\"INCLUDE={envVars["INCLUDE"]}\",\n");

			if (envVars.ContainsKey("LIB"))
				envs.Add($"\t\t\"LIB={envVars["LIB"]}\",\n");

			CreateBffFileSetting(envs);

			return true;
		}
		private bool CreateBffFile_Mac()
		{
			//这是mac打mac、ios、tvos包头

			AddText($".MacBaseSDKDir = '{MacToolChain.Settings.BaseSDKDir}'\n");
			AddText($".MacToolchainDir = '{MacToolChain.Settings.ToolchainDir}'\n");
			AddText($"Compiler('UEAppleCompiler') \n{{\n");
			AddText($"\t.Executable = '$MacToolchainDir$/clang++'\n");
			AddText($"\t.ClangRewriteIncludes = false\n"); // This is to fix an issue with iOS clang builds, __has_include, and Objective-C #imports
			AddText($"}}\n\n");


			CreateBffFileSetting();

			return false;
		}
		private bool CreateBffFile_IOS(IEnumerable<Action> Actions, string BffFilePath)
		{
			return false;
		}
		private bool CreateBffFile_Android()
		{
			//Android Support
			var toolChain = AndroidExports.CreateToolChain(targetDescriptor.ProjectFile) as AndroidToolChain;

			var ndkRoot = Environment.GetEnvironmentVariable("NDKROOT");
			var ndkApiLevel = toolChain.GetNdkApiLevel().Split('-')[1];

			if (BuildHostPlatform.Current.Platform == UnrealTargetPlatform.Win64)
			{
				AddText($".NDKRoot = '{ndkRoot}'\n");
				AddText($".NDKToolchains       = '$NDKRoot$\\toolchains'\n");
				AddText($".NATIVE_API_LEVEL = '{ndkApiLevel}'\n");
				AddText($".NDKToolchainVersion = '4.9'\n");
				//AddText($".NDKToolchainArmType = 'arm-linux-androideabi''\n"); 禁用arm-v7a
				AddText($".NDKToolchainArm64Type = 'aarch64-linux-android'\n");
				//AddText($".NDKToolchainX86Type = 'i686-linux-android'\n"); 禁用x86
				AddText($".NDKToolchainArmGccRoot = '$NDKToolchains$\\arm-linux-androideabi-4.9\\prebuilt\\windows-x86_64'\n");
				AddText($".NDKToolchainArmRoot = '$NDKToolchainArmGccRoot$\\bin'\n");
				AddText($".NDKGCCArmLibs = '$NDKToolchainArmGccRoot$\\lib\\gcc\\arm-linux-androideabi\\4.9.x'\n");
				AddText($".NDKToolchainClangRoot = '$NDKToolchains$\\llvm\\prebuilt\\windows-x86_64\\bin'\n");
				AddText($".NDKToolchainSysRoot = '$NDKToolchains$\\llvm\\prebuilt\\windows-x86_64\\sysroot\\usr'\n");
				AddText($".NDKBaseSysRoot = '$NDKToolchains$\\sysroot\\usr'\n");
				AddText($".NDKPlatform         = 'android-$NATIVE_API_LEVEL$'\n");

				string compilerStr = "Compiler( 'clang++' )\n" +
				"{\n" +
				"    .Executable     = '$NDKToolchainClangRoot$\\clang++.exe'\n" +
				"    .ExtraFiles     = '$NDKToolchainClangRoot$\\libwinpthread-1.dll'\n" +
				"}\n" +

				"Compiler( 'clang' )\n" +
				"{\n" +
				"    .Executable     = '$NDKToolchainClangRoot$\\clang.exe'\n" +
				"    .ExtraFiles     = '$NDKToolchainClangRoot$\\libwinpthread-1.dll'\n" +
				"}\n";
				AddText(compilerStr);

			}
			else if (BuildHostPlatform.Current.Platform == UnrealTargetPlatform.Mac)
			{

			}
			return true;
		}
		private void CreateBffFileSetting(List<string> envs = null)
		{
			AddText("Settings \n{\n");
			if (bEnableCaching)
			{
				string CachePath = GetCachePath();
				if (!string.IsNullOrEmpty(CachePath))
					AddText($"\t.CachePath = '{CachePath}'\n");
			}

			if (bEnableDistribution)
			{
				string BrokeragePath = GetBrokeragePath();
				if (!string.IsNullOrEmpty(BrokeragePath))
					AddText($"\t.BrokeragePath = '{BrokeragePath}'\n");
			}
			//集群最大连接数
			AddText($"\t.WorkerConnectionLimit = 100\n");

			AddText("\t.Environment = \n\t{\n");
			if (envs != null)
				AddText(string.Join("", envs));
			AddText("\t}\n"); //End environment



			AddText("}\n\n"); //End Settings
		}


		private bool ExecuteBffFile(string BffFilePath)
		{
			string CacheArgument = "";

			if (bEnableCaching)
			{
				switch (CacheMode)
				{
					case FASTBuildCacheMode.ReadOnly:
						CacheArgument = "-cacheread";
						break;
					case FASTBuildCacheMode.WriteOnly:
						CacheArgument = "-cachewrite";
						break;
					case FASTBuildCacheMode.ReadWrite:
						CacheArgument = "-cache";
						break;
				}
			}

			string DistArgument = bEnableDistribution ? "-dist" : "";
			string ForceRemoteArgument = bForceRemote ? "-forceremote" : "";
			string NoStopOnErrorArgument = bStopOnError ? "" : "-nostoponerror";
			//string IDEArgument				= BuildHostPlatform.Current.Platform == UnrealTargetPlatform.Win64 ? "-ide" : "";
			string IDEArgument = "";

			// schtasks /Create /SC ONLOGON /TN "FASTBuildWorker" /TR E:\softwave\UE_4.25\Engine\Extras\ThirdPartyNotUE\FASTBuild\Win64\FBuildWorker.exe
			// reg ADD HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Run /v FBuildWorker.exe /t REG_SZ /d E:\softwave\UE_4.25\Engine\Extras\ThirdPartyNotUE\FASTBuild\Win64\FBuildWorker.exe
			// Interesting flags for FASTBuild:
			// -nostoponerror, -verbose, -monitor (if FASTBuild Monitor Visual Studio Extension is installed!)
			// Yassine: The -clean is to bypass the FASTBuild internal
			// dependencies checks (cached in the fdb) as it could create some conflicts with UBT.
			// Basically we want FB to stupidly compile what UBT tells it to.
			string FBCommandLine = $"-monitor -summary {DistArgument} {CacheArgument} {IDEArgument} -config \"{BffFilePath}\" {NoStopOnErrorArgument} {ForceRemoteArgument}";
			FBCommandLine += " -clean";
			FBCommandLine += " -showcmds -distverbose";
			Log.TraceInformation($"FBuild Command Line Arguments: '{FBCommandLine}");

			string FBExecutable = GetExecutablePath();
			string WorkingDirectory = Path.GetFullPath(Path.Combine(UnrealBuildTool.EngineDirectory.MakeRelativeTo(DirectoryReference.GetCurrentDirectory()), "Source"));

			ProcessStartInfo FBStartInfo = new ProcessStartInfo(FBExecutable, FBCommandLine);
			FBStartInfo.UseShellExecute = false;
			FBStartInfo.WorkingDirectory = WorkingDirectory;
			FBStartInfo.RedirectStandardError = true;
			FBStartInfo.RedirectStandardOutput = true;

			FBStartInfo.EnvironmentVariables.Remove("FASTBUILD_BROKERAGE_PATH"); // remove stale serialized value and defer to GetBrokeragePath
			string BrokeragePath = GetBrokeragePath();
			if (!string.IsNullOrEmpty(BrokeragePath) && !FBStartInfo.EnvironmentVariables.ContainsKey("FASTBUILD_BROKERAGE_PATH"))
			{
				FBStartInfo.EnvironmentVariables.Add("FASTBUILD_BROKERAGE_PATH", BrokeragePath);
			}
			string CachePath = GetCachePath();
			if (!string.IsNullOrEmpty(CachePath) && !FBStartInfo.EnvironmentVariables.ContainsKey("FASTBUILD_CACHE_PATH"))
			{
				FBStartInfo.EnvironmentVariables.Add("FASTBUILD_CACHE_PATH", CachePath);
			}

			try
			{
				//var CompileLogPath = Utils.GetLogFilePath($"{DateTime.Now.Ticks}_CompileLog.log");
				//Log.TraceInformation($"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!{CompileLogPath.FullName}");
				//var CompileLogTrace = Log.AddFileWriter("CompileLogTrace", CompileLogPath);
				Process FBProcess = new Process();
				FBProcess.StartInfo = FBStartInfo;
				FBProcess.EnableRaisingEvents = true;

				DataReceivedEventHandler OutputEventHandler = (Sender, Args) =>
				{
					if (Args.Data != null)
						Log.TraceInformation(Args.Data);
				};

				FBProcess.OutputDataReceived += OutputEventHandler;
				FBProcess.ErrorDataReceived += OutputEventHandler;

				FBProcess.Start();

				FBProcess.BeginOutputReadLine();
				FBProcess.BeginErrorReadLine();

				FBProcess.WaitForExit();
				//Log.RemoveTraceListener(CompileLogTrace);

				return FBProcess.ExitCode == 0;
			}
			catch (Exception e)
			{
				Log.TraceError("Exception launching fbuild process. Is it in your path?" + e.ToString());
				return false;
			}
		}



		private string LocalizationDirSep(string path)
		{
			path = path.Replace('\\', Path.DirectorySeparatorChar);
			path = path.Replace('/', Path.DirectorySeparatorChar);
			return path;
		}
		public string GetRegistryValue(string keyName, string valueName, object defaultValue)
		{
			object returnValue = (string)Microsoft.Win32.Registry.GetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\" + keyName, valueName, defaultValue);
			if (returnValue != null)
				return returnValue.ToString();

			returnValue = Microsoft.Win32.Registry.GetValue("HKEY_CURRENT_USER\\SOFTWARE\\" + keyName, valueName, defaultValue);
			if (returnValue != null)
				return returnValue.ToString();

			returnValue = (string)Microsoft.Win32.Registry.GetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Wow6432Node\\" + keyName, valueName, defaultValue);
			if (returnValue != null)
				return returnValue.ToString();

			returnValue = Microsoft.Win32.Registry.GetValue("HKEY_CURRENT_USER\\SOFTWARE\\Wow6432Node\\" + keyName, valueName, defaultValue);
			if (returnValue != null)
				return returnValue.ToString();

			return defaultValue.ToString();
		}


		//////////////////////////////////////////
		// Action Helpers

		private ObjectIDGenerator objectIDGenerator = new ObjectIDGenerator();

		private long GetActionID(Action Action)
		{
			bool bFirstTime = false;
			return objectIDGenerator.GetId(Action, out bFirstTime);
		}

		private string ActionToActionString(Action Action)
		{
			return ActionToActionString(GetActionID(Action));
		}

		private string ActionToActionString(long UniqueId)
		{
			return $"Action_{UniqueId}";
		}

		private string ActionToDependencyString(Action Action, string StatusDescription, string CommandDescription = null, ActionType? ActionType = null)
		{
			string ExtraInfoString = null;
			if ((CommandDescription != null) && string.IsNullOrEmpty(CommandDescription))
				ExtraInfoString = CommandDescription;
			else if (ActionType != null)
				ExtraInfoString = ActionType.Value.ToString();

			if ((ExtraInfoString != null) && !string.IsNullOrEmpty(ExtraInfoString))
				ExtraInfoString = $" ({ExtraInfoString})";

			return $"\t\t'{ActionToActionString(Action)}', ;{StatusDescription}{ExtraInfoString}";
		}

		private string ActionToDependencyString(Action Action)
		{
			return ActionToDependencyString(Action, Action.StatusDescription, Action.CommandDescription, Action.ActionType);
		}
		public bool IsPCHAction(Action a)
		{
			foreach (var item in a.ProducedItems)
			{
				if (item.Name.Contains("PCH"))
				{
					return true;
				}
			}
			return false;
		}

		public static string GetExecutableName()
		{
			return Path.GetFileName(GetExecutablePath());
		}

		public static string GetExecutablePath()
		{
			if (string.IsNullOrEmpty(FBuildExecutablePath))
			{
				string EnvPath = Environment.GetEnvironmentVariable("FASTBUILD_EXECUTABLE_PATH");
				if (!string.IsNullOrEmpty(EnvPath))
				{
					FBuildExecutablePath = EnvPath;
				}
			}

			return FBuildExecutablePath;
		}

		public static string GetCachePath()
		{
			if (string.IsNullOrEmpty(FBuildCachePath))
			{
				string EnvPath = Environment.GetEnvironmentVariable("FASTBUILD_CACHE_PATH");
				if (!string.IsNullOrEmpty(EnvPath))
				{
					FBuildCachePath = EnvPath;
				}
			}

			return FBuildCachePath;
		}

		public static string GetBrokeragePath()
		{
			if (string.IsNullOrEmpty(FBuildBrokeragePath))
			{
				string EnvPath = Environment.GetEnvironmentVariable("FASTBUILD_BROKERAGE_PATH");
				if (!string.IsNullOrEmpty(EnvPath))
				{
					FBuildBrokeragePath = EnvPath;
				}
			}

			return FBuildBrokeragePath;
		}

	}

}
