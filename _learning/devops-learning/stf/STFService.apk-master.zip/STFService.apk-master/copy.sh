set -xe
cp app/build/outputs/apk/app-release.apk ../stf/vendor/STFService/STFService.apk
cp app/src/main/proto/wire.proto ../stf/vendor/STFService/wire.proto
