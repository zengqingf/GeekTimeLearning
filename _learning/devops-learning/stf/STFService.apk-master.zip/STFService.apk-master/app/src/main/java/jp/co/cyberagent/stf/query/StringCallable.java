package jp.co.cyberagent.stf.query;

@FunctionalInterface
interface StringCallable {
    String call();
}
