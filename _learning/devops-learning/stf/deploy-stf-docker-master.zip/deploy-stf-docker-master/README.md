# deploy-stf-docker
Scripts to deploy STF master server on Ubuntu with one-button operation
