﻿#if NET20

namespace System.Runtime.CompilerServices
{
    /// <summary>
    /// 扩展方法必要的特性。
    /// </summary>
    public class ExtensionAttribute : Attribute
    {
    }
}

#endif