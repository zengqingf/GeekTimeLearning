﻿namespace Swifter.Tools
{
    enum StaticsBaseBlock
    {
        GC = 1,
        NonGC = 0,
        ThreadGC = 3,
        ThreadNonGC = 2
    }
}