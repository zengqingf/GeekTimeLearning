﻿namespace Swifter.Tools
{
    internal class StructBox<T>
    {
        public T Value;
    }
}