﻿using Swifter.Tools;

namespace Swifter.Json
{
    static class JsonArrayAppendingInfo<T>
    {
        public static ArrayAppendingInfo AppendingInfo = new ArrayAppendingInfo { MostClosestMeanCommonlyUsedLength = 3 };
    }
}
