﻿
#if NETFRAMEWORK

using Swifter.Json;
using System;
using System.Text;
using System.Web.Mvc;

using static SwifterExtensions;

public static partial class SwifterExtensions
{
}

#endif