﻿using System;

namespace Swifter.Test.WPF
{
    public sealed class IncorrectException : Exception
    {

    }
}