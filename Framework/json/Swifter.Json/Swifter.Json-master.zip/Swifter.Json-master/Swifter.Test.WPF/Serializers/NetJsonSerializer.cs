﻿namespace Swifter.Test.WPF.Serializers
{
    //public sealed class NetJsonSerializer : BaseSerializer<string>
    //{
    //    public override TObject Deserialize<TObject>(string symbols)
    //    {
    //        return NetJSON.NetJSON.Deserialize<TObject>(symbols);
    //    }

    //    public override string Serialize<TObject>(TObject obj)
    //    {
    //        return NetJSON.NetJSON.Serialize(obj);
    //    }
    //}
}
