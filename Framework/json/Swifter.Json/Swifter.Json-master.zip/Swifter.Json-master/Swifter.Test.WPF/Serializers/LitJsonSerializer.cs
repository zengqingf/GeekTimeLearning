﻿namespace Swifter.Test.WPF.Serializers
{
    //public sealed class LitJsonSerializer : BaseSerializer<string>
    //{
    //    public override TObject Deserialize<TObject>(string symbols)
    //    {
    //        return LitJson.JsonMapper.ToObject<TObject>(symbols);
    //    }

    //    public override string Serialize<TObject>(TObject obj)
    //    {
    //        return LitJson.JsonMapper.ToJson(obj);
    //    }
    //}
}
