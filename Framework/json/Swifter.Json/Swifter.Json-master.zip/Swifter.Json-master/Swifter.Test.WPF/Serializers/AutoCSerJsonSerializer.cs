﻿namespace Swifter.Test.WPF.Serializers
{
    //public sealed class AutoCSerJsonSerializer : BaseSerializer<string>
    //{
    //    public override TObject Deserialize<TObject>(string symbols)
    //    {
    //        return AutoCSer.Json.Parser.Parse<TObject>(symbols);
    //    }

    //    public override string Serialize<TObject>(TObject obj)
    //    {
    //        return AutoCSer.Json.Serializer.Serialize(obj);
    //    }
    //}
}
