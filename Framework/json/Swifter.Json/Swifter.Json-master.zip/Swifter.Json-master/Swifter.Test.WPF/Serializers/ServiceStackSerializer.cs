﻿namespace Swifter.Test.WPF.Serializers
{
    //public sealed class ServiceStackSerializer : BaseSerializer<string>
    //{
    //    public override TObject Deserialize<TObject>(string symbols)
    //    {
    //        return ServiceStack.Text.JsonSerializer.DeserializeFromString<TObject>(symbols);
    //    }

    //    public override string Serialize<TObject>(TObject obj)
    //    {
    //        return ServiceStack.Text.JsonSerializer.SerializeToString(obj);
    //    }
    //}
}
