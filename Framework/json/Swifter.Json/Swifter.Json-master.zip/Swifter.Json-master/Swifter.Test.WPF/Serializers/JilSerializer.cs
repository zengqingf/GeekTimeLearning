﻿namespace Swifter.Test.WPF.Serializers
{
    public sealed class JilSerializer : BaseSerializer<string>
    {
        public override TObject Deserialize<TObject>(string symbols)
        {
            return Jil.JSON.Deserialize<TObject>(symbols);
        }

        public override string Serialize<TObject>(TObject obj)
        {
            return Jil.JSON.Serialize(obj);
        }
    }
}