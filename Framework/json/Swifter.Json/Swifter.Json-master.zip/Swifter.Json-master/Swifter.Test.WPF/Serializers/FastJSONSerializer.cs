﻿namespace Swifter.Test.WPF.Serializers
{
    //public sealed class FastJSONSerializer : BaseSerializer<string>
    //{
    //    public override TObject Deserialize<TObject>(string symbols)
    //    {
    //        return fastJSON.JSON.ToObject<TObject>(symbols);
    //    }

    //    public override string Serialize<TObject>(TObject obj)
    //    {
    //        return fastJSON.JSON.ToJSON(obj);
    //    }
    //}
}
