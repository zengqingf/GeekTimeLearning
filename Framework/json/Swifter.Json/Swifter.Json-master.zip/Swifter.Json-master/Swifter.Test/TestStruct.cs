﻿namespace Swifter.Test
{
    public struct TestStruct
    {
        public string Name { get; set; }

        public int? Nullable { get; set; }

        public int Count { get; set; }
    }
}