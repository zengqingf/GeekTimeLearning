﻿namespace Swifter.Data
{
    /// <summary>
    /// T-SQL 条件连接符
    /// </summary>
    public enum ConditionTypes
    {
        /// <summary>
        /// AND
        /// </summary>
        And,
        /// <summary>
        /// OR
        /// </summary>
        Or
    }
}