﻿using System.Collections.Generic;

namespace Swifter.Data.Sql
{
    /// <summary>
    /// 分组列集合。
    /// </summary>
    public sealed class GroupBies : List<Column>
    {

    }
}