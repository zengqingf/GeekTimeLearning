﻿using System.Collections.Generic;

namespace Swifter.Data.Sql
{
    /// <summary>
    /// 排序集合。
    /// </summary>
    public sealed class OrderBies : List<OrderBy>
    {

    }
}