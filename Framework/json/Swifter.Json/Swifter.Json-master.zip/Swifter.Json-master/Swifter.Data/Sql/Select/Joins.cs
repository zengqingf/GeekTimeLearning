﻿using System.Collections.Generic;

namespace Swifter.Data.Sql
{
    /// <summary>
    /// 表连接集合
    /// </summary>
    public sealed class Joins : List<Join>
    {

    }
}