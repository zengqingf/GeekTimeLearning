﻿using System.Collections.Generic;

namespace Swifter.Data.Sql
{
    /// <summary>
    /// 查询列的集合。
    /// </summary>
    public sealed class SelectColumns : List<SelectColumn>
    {

    }
}