﻿using System.Collections.Generic;

namespace Swifter.Data.Sql
{
    /// <summary>
    /// 赋值集合
    /// </summary>
    public sealed class AssignValues : List<AssignValue>
    {
    }
}