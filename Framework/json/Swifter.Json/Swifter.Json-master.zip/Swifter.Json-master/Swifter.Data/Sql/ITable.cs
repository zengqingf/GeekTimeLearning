﻿namespace Swifter.Data.Sql
{
    /// <summary>
    /// 表示一个表
    /// </summary>
    public interface ITable
    {
    }
}