﻿namespace Swifter.Data.Sql
{
    /// <summary>
    /// 表示一个值
    /// </summary>
    public interface IValue
    {
    }
}