﻿namespace Swifter.MessagePack
{
    static class MessagePackExtensionCode
    {
        public const sbyte Timestamp = -1;

        public const sbyte Reference = -10;
    }
}