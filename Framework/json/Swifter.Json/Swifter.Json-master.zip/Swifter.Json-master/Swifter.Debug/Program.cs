﻿namespace Swifter.Debug
{
    public sealed class Program
    {

        public static void Main()
        {
        }
    }
}