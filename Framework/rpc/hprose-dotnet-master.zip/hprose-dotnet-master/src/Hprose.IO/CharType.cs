﻿/*--------------------------------------------------------*\
|                                                          |
|                          hprose                          |
|                                                          |
| Official WebSite: https://hprose.com                     |
|                                                          |
|  CharType.cs                                             |
|                                                          |
|  hprose CharType enum for C#.                            |
|                                                          |
|  LastModified: Jan 10, 2019                              |
|  Author: Ma Bingyao <andot@hprose.com>                   |
|                                                          |
\*________________________________________________________*/

namespace Hprose.IO {
    public enum CharType {
        String, Char
    }
}
