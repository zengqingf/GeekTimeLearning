#!/bin/sh

set FLASK_APP=server.py
python -m flask run