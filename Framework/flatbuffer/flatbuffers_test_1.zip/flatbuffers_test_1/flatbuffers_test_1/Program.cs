﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FlatBuffers;
using TestFB;

namespace flatbuffers_test_1
{
    class Program
    {
        static void Main(string[] args)
        {
        }



        //encode
        static byte[] EncodeTest(string[] names)
        {
            FlatBufferBuilder fbBuilder = new FlatBufferBuilder(1);

            Offset<People>[] peppleOffsets = new Offset<People>[names.Length];
            for (int i = 0; i < names.Length; i++)
            {
                int typeCount = (int)PhoneType.COUNT;
                var phoneOffsets = new Offset<PhoneNumber>[typeCount];
                for (int j = 0; j < typeCount; j++)
                {
                    string formatPhoneNumber = string.Format("{0:D11}", 10000000000 + j + i * 3);
                    var phoneNumber = fbBuilder.CreateString(formatPhoneNumber);
                    var phoneOffset = PhoneNumber.CreatePhoneNumber(fbBuilder, phoneNumber, j);
                    phoneOffsets[j] = phoneOffset;
                }
                var pOffset = People.CreatePhoneVector(fbBuilder, phoneOffsets);
                var name = fbBuilder.CreateString(names[i]);
                var peopleOffset = People.CreatePeople(fbBuilder, name, 100 + i, pOffset);
                peppleOffsets[i] = peopleOffset;
            }
            var offset = AddressBook.CreatePeopleVector(fbBuilder, peppleOffsets);

            AddressBook.StartAddressBook(fbBuilder);
            AddressBook.AddPeople(fbBuilder, offset);
            var eab = AddressBook.EndAddressBook(fbBuilder);
            AddressBook.FinishAddressBookBuffer(fbBuilder, eab);
            return fbBuilder.SizedByteArray();
        }

        static byte[] EncodeTest2(string name, int age)
        {
            FlatBufferBuilder fbBuilder = new FlatBufferBuilder(1);
            int typeCount = (int)PhoneType.COUNT;
            var phoneOffsets = new Offset<PhoneNumber>[typeCount];
            for (int j = 0; j < typeCount; j++)
            {
                string formatPhoneNumber = string.Format("{0:D11}", 10000000000 + j + i * 3);
                var phoneNumber = fbBuilder.CreateString(formatPhoneNumber);
                var phoneOffset = PhoneNumber.CreatePhoneNumber(fbBuilder, phoneNumber, j);
                phoneOffsets[j] = phoneOffset;
            }

            var phoneVecOffset = People.CreatePhoneVector(fbBuilder, phoneOffsets);
            var nameStrOffset = fbBuilder.CreateString(name);
            var peopleTypeOffset = People.CreatePeople(fbBuilder, nameStrOffset, age, phoneVecOffset);

            var peopleTypeOffsets = new Offset<People>[1] { peopleTypeOffset };

            var peopleVecOffset = AddressBook.CreatePeopleVector(fbBuilder, peopleTypeOffsets);
            AddressBook.StartAddressBook(fbBuilder);
            AddressBook.AddPeople(fbBuilder, peopleVecOffset);
        }

        //decode
        static AddressBook DecodeTest(byte[] datas)
        {
            ByteBuffer byteBuffer = new ByteBuffer(datas);
            return AddressBook.GetRootAsAddressBook(byteBuffer);
        }
    }
}
