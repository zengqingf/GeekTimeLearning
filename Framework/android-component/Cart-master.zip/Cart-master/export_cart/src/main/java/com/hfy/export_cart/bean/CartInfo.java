package com.hfy.export_cart.bean;

/**
 * 购物车信息
 *
 * @author hufeiyang
 */
public class CartInfo {

    /**
     * 商品数量
     */
    public int productCount;
}
