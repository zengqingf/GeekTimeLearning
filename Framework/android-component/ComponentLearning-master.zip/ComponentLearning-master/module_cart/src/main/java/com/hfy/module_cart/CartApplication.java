package com.hfy.module_cart;

import android.app.Application;

public class CartApplication extends Application {
}
