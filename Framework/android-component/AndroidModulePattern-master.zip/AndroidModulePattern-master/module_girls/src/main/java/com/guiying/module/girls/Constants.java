package com.guiying.module.girls;

/**
 * 保存项目中用到的常量
 */
public interface Constants {

    /**
     * http://gank.io/api/data/福利/10/1
     */
    String GAN_HUO_API = "http://gank.io/api/data/";

    String INTENT_GIRLS = "girls";
    String INTENT_INDEX = "index";

}
