IIPS Package Management Tool
Develop and Maintained by Andy Tao
Copyright (C) 2012 IEGRD Download Develop Team, Tencent Inc.

Usage: 
    Packager new [switches] <Package> 
    Packager new [switches] <Package> <Local File Path | @file list> 
    Packager add [switches] <Package> <Local File Path | @file list>  
    Packager get <Package> <* | Virtual File Path> <Local File Path>
    Packager patch [switches]  <Base Package> <New Package> <Patch Package>   (not recommand)
    Packager patchlist [switches] <"base1.ifs basepatch1.ifs ....">  <"full.ifs full.patch1.ifs ...">  <Package>
    Packager patchdir [switches] <"base1.ifs basepatch1.ifs ....">  <Local File Path>  <Package> (<sub vitual path>)
    Packager verify <Package> [Virtual File Path]
    Packager <open|clear> <Package>
    Packager getentrycount <Package>
    Packager getmaxentrycount <Package>
    Packager setmaxentrycount <Package> <NewEntryCount>
    
    compatible with iips 1.x filter/group tools
    Packager filter [switches] <source path> <target path> 
    Packager group [switches] <source path> <sqlite3 file> 
    Packager export [switches] <sqlite3 file> <target path>  
    Packager gpack [switches] <listfile path | SQLite3 db> <source path> <target package path> 
    Packager merge [switches] <Patch1> <Patch2> <target merge_package path>   (not recommand)
    Packager mergelist [switches] <"patch1 patch2 ...">
    
    Packager backup [switches] <Packager> 
    Packager extractbackup [switches] <Back Up File Path> 
    Packager arrange <"base1.ifs basepatch1.ifs ....">  <"full.ifs full.patch1.ifs ...">  <Package>
    
    Packager setlist <"package1.ifsf package2.ifs ...">
    Packager encrypt <Package> <password>
    Packager decrypt <Package> <password>  

action: 
    action = <help|new|add|get|open|patch|clear|verify|filter|group|gpack|getentrycount|getmaxentrycount|setmaxentrycount|merge|patchlist|mergelist|patchdir|backup|extractbackup|decrypt|encrypt>

switches:
    <new>: 
        -diroff                                     exclude source folder, default include source path
        -zip=<zlib/bzip2/unzip>                     choose compress algorithm, lzma not implement
        -skip=<_HIDDEN_|pattern>                    exclude file or path by pattern, ex: -skip=_ZERO_ -skip=.svn
        -srcdir=<path for file in list>	            set source file path for file in list, default: list file path
        -createalways                               overwrite existed package when create new package
        -showprogress                               show progress
        -include = .xxx                             pack file of.xxx only
        -virpath = xxx                              xx is your root virtual path in package
    <add>: 
        -diroff                                     exclude source folder, default include source path
        -zip=<zlib/bzip2/lzma/unzip>                     choose compress algorithm, lzma not implement
        -skip=<_HIDDEN_|pattern>                    exclude file or path by pattern, ex: -skip=_ZERO_ -skip=.svn
        -srcdir=<path for file in list>	            set source file path for file in list, default: list file path
        -showprogress                               show progress
        -include = .xxx                             pack file of.xxx only
        -virpath = xxx                              xx is your root virtual path in package

    <patch>:
        -createalways                               overwrite existed package when create new patch package
        -showprogress                               show progress

    <merge>:
        -createalways                               overwrite existed package when create new patch_merge package

    <filter>:
        -maxsize=<N[B|K[B]|M[B]|G[B]|T[B]|P[B]]>    max file size
        -minsize=<N[B|K[B]|M[B]|G[B]|T[B]|P[B]]>    min file size
        -skipfile=pattern                           exclude file or path by pattern, ex: -skip=.pdb -skip=.svn
        -skipattr=<_HIDDEN_|...>                    exclude file or path by attribute
    
    <group>:
        -maxsize=<N[B|K[B]|M[B]|G[B]|T[B]|P[B]]>    max group file size
        -maxfile=<N>                                max group file number
        -skipfile=pattern                           exclude file or path by pattern, ex: -skip=.pdb -skip=.svn
        -travel=<dfs|bfs>                           how to list files in dir <dfs|bfs>?, default: dfs
        -sort=<none|asc|desc>                       how to sort files in dir by size <none|asc|desc>, default: none
    
    <export> 
        -prefix=<prefix>                            filelist or package file prefix 

    <gpack> 
        -prefix=<prefix>                            filelist or package file prefix   
        
    <patchlist> 
        -createalways                               overwrite existed package when create new patch package
    
    <patchdir>
        -createalways                               overwrite existed package when create new patch package
        -diroff                                     exclude source folder, default include source path
        -skip=<pattern|_HIDDEN_>                    exclude file or path by pattern, ex: -skip=.pdb -skip=.svn
        -zip=<zlib/bzip2/lzma/unzip>                     choose compress algorithm, lzma not implement
        -showprogress                               show progress
        -include = .xxx                             pack file of.xxx only

        
    <mergelist>
        -createalways                               overwrite existed package when create new merge package

    <clear>
        -password                                   clear package with password
    
    <backup>
        -createalways                               overwrite existed package when create new backup file
        
    <extractbackcup>
        -createalways                               overwrite existed package when create new package from backup
notice: 
    file path with prefix(@) tell it is list file, ex: @listfile.lst
    The first letter of filename can't be "-"!
    if path contained space,you should include it with ""
    in command "patchlist" and "mergelist",if filename contained space,you could include it with <>
    For example,I have a packagr named "bl ank.ifs".If i want to use mergelist to merge it with others,i can use it as this:
    packager mergelist "<bl ank.ifs> xxx.ifs xxx.ifs" new.ifs

example: 
    Packager new test.ifs
    Packager new -createalways test.ifs
    Packager new -include=.txt test.ifs c:\windows
    Packager new test.ifs @list.lst
    Packager add test.ifs C:\Windows\Cursors
    Packager add test.ifs @c:\window\Cursors\list.lst
    Packager add -diroff -skip=_ZERO_ -skip=.obj test.ifs C:\Windows\Cursors
    Packager get test.ifs * c:\temp\
    Packager get test.ifs TestDir c:\temp\
    Packager get test.ifs TestDir\aero_busy.ani c:\temp\
    Packager verify test.ifs TestDir\aero_busy.ani
    Packager getentrycount C:\Windows\Cursors\test.ifs
    Packager getmaxentrycount C:\Windows\Cursors\test.ifs
    Packager setmaxentrycount C:\Windows\Cursors\test.ifs 50000
    Packager merge patch1.ifs patch2.ifs patch_merge.ifs
    Packager patchlist -createalways "base1.ifs base_patch1.ifs"  "full.ifs full_patch1.ifs"  base_patch2.ifs
    Packager patchdir -diroff -skip=.txt -createalways "base1.ifs base_patch1.ifs"  "full.ifs full_patch1.ifs"  base_patch2.ifs
    Packager mergelist -createalways "base1.ifs base_patch1.ifs base_patch2.ifs" base_merge.ifs
    Packager backup -createalways test.ifs 
    Packager extractbackup -createalways test.res
    IIPS 1.x compatible commands can refer IIPS1xCmd.cmd
    
