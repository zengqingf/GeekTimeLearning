# 下载更新工具集


## ChannelTools
apk 打渠道工具，此工具由飞鹰提供，目前支持V1,V2签名的apk渠道号打包。

## dolphin_tools
dolphin 打包工具：包含mac windows平台下的ifs创建，res制作工具

## puffer_tools
puffer eifs打包工具：包含mac windows 平台下eifs的创建