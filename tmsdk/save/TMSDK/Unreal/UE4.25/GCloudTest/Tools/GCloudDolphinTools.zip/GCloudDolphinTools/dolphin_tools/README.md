# Mac

./nifs create yourgame/Assets/StreamingAssets ifsname_versionid.ifs


# Windows

Packager.com new -diroff ifsname.ifs d:\\yougame\Assets\StreamingAssets 

### tips:

your root directory's resource must in the path like "yourgame/Assets/StreamingAssets" and d:\\yougame\Assets\StreamingAssets ,the mac commander will not include path,but windows will if the commander without '-diroff'