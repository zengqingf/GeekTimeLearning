# create IFS:

./nifs create ifs_dir test.ifs compress
eg:./nifs create /root/resource /root/first_source.ifs compress
# create res：

./nifs backup  *.ifs *.ifs.res filelist.json
eg：./nifs backup /root/first_source.ifs.res /root/filist.json