#ifndef GCLOUD_VERSION__H
#define GCLOUD_VERSION__H

#define GCLOUD_VERSION_S "2.1.00.200824"
#define GCLOUD_VERSION_HASH "hash_2c7cce85620c0b57f339e5296d04de9913b208e6"

const char *gcloud_get_version();
const char *gcloud_get_version_hash();

#endif
