//
//  TGPAPerformanceAdjuster.h
//  kgvmp
//
//  Created by zohnzliu(刘专) on 2018/7/10.
//  Copyright © 2018年 tgpa. All rights reserved.
//
#import "kgvmp.h"

#ifndef TGPAPerformanceAdjuster_h
#define TGPAPerformanceAdjuster_h


@interface TGPAPerformanceAdjuster : NSObject

+ (instancetype)getInstance;

+ (void)setLogAble:(BOOL)enable;
+ (void)enableDebugMode;
+ (NSInteger)getVersionCode;
+ (NSString*)getVersionName;

- (void)initTGPA;
- (BOOL)checkSdkCanWork;
- (void)registerVmpCallback:(VmpCallbackDelegate)callback;
- (void)updateGameInfoInt:(NSInteger)key theValue:(NSString *)value;
- (void)updateGameInfoString:(NSString *)key theValue:(NSString *)value;
- (void)updateGameFPS:(float[])fpsArr;
- (void)postMatchFPSData:(NSInteger)length fpsList:(NSMutableArray* )fpsArr;
- (NSString*)getDataFromTGPA:(NSString*)key theValue:(NSString*) value;

@end


#endif /* TGPAPerformanceAdjuster_h */
