//
//  BeaconAnaModel.h
//  Beacon
//
//  Created by dong kerry on 11-12-22.
//  Copyright (c) 2011年 tencent.com. All rights reserved.
//
#import "TDMTunnelInfo.h"

@interface TDMBeaconAnaModel : NSObject

@property (nonatomic,retain) NSString * appId;

@property (atomic,retain) NSString * appVersion;

@property (atomic,retain) NSString * sdkVersion;

@property (atomic,retain) NSString * bundleId;

@property (nonatomic,assign) int platformId;

@property (atomic,retain) NSString * hardwareOs;

@property (atomic,retain) NSString * qua;

@property (atomic,retain) NSString * guid;

@property (atomic,retain) NSString * gatewayIP;

@property (atomic,retain) NSString * osVer;

@property (nonatomic,assign) float osVerFloat;

@property (atomic,retain) NSString* hardwareModel;

@property (atomic,retain) NSString* verHash;//计算的ersion hash'
@property (atomic,retain) NSString* localVer;//存储的version hash

@property (atomic,retain) NSString* country;

@property (atomic,retain) NSString* language;

@property (nonatomic,assign) long long romSize;

@property (nonatomic,assign) long long ramSize;

@property (atomic,retain) NSString* openudid;

@property (nonatomic,assign) long long lastRecordTime;

@property (atomic,retain) NSString* udidVendor;//idfv

@property (atomic,retain) NSString* advUid;//idfa

@property (nonatomic,assign) BOOL isReet;//isroot

@property (atomic,retain) NSString* channel_id;

@property (atomic,retain) NSString* resolution;

@property (atomic,retain) NSString* sessionid;

@property (atomic,retain) NSString* QQ;

@property (atomic,retain) NSString * omgId;

@property (atomic, retain) NSDictionary *addParams;

//是否纯新增用户
@property (nonatomic,assign) BOOL isnew;
//是否版本新增用户
@property (nonatomic,assign) BOOL isNewWithVer;

@property (atomic,retain) NSString* macadd;

@property (atomic,retain) NSString* wifiName;

@property (atomic,retain) NSString* mbCarrier;//运营商

@property (atomic,retain) NSString* imsi;

@property (atomic,retain) NSString* wifiMac;

@property (atomic,retain) NSString* networkType;

@property (atomic,retain) NSString * apn;

@property (nonatomic,assign) long long appUseTime;

@property (nonatomic,assign) long long appAvaTime;


@property (nonatomic, strong) NSString *processName;

@property (nonatomic, assign) BOOL isSimulator;

@property (nonatomic, assign) BOOL isCold;//是否冷启动

@property (nonatomic, strong) NSString *launchSource;

@property (nonatomic, assign) long long firstInstallTime;

@property (nonatomic, assign) long long lastUpgradeTime;

@property (nonatomic,assign) long serverTimeDelta;

@property (nonatomic,assign) BOOL hasSyncServerTime;

@property (nonatomic, strong) NSString *deviceName;

@property (nonatomic, strong) NSString *battery;

@property (nonatomic, strong) NSString *wlanDevices;//all_ssid

+ (instancetype)getDefualtBeaconAnaModel;

- (BOOL) isVersionChanged;

- (BOOL)isSdkVersionChanged;

- (void)initBeaconProperties;

- (void)refreshNetInfo;

//为通道设置userId
- (void)setUserIdToTunnel:(NSString *)appKey userId:(NSString *)userId;

//为通道设置渠道
- (void)setChannelIdToTunnel:(NSString *)appKey channelId:(NSString *)channelId;

//为通道设置app版本
- (void)setAppVersionToTunnel:(NSString *)appKey appVersion:(NSString *)appVersion;

//QIMEI
- (void)setQIMEI:(NSString *)qimei;

- (NSString *)getQIMEI;

- (NSString *)getQIMEIA3;

- (NSString *)getQIMEIA153;

- (NSString * )getQIMEIWithKey:(NSString *)key;

- (TDMTunnelInfo *)getTunnelInfo:(NSString *)appKey;

- (void)registerTunnel:(NSString *)appKey userId:(NSString *)userId channelId:(NSString *)channelId appVersion:(NSString *)appVersion;

//serverTimeDelta
- (void)setDelta:(long)delta;

- (void)persistKey:(NSString*) key value:(id) val;

- (id)getKey:(NSString*) key;

- (void)setKey:(NSString*) key value:(id) val;

- (void)unSetKey:(NSString*) key;

- (void)persistAllKey;

- (NSMutableDictionary *)getDTParam;

@end
