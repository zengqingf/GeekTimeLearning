//
//  TunnelInfo.h
//  Beacon
//
//  Created by wangnaikun on 2019/9/16.
//  Copyright © 2019 tencent.com. All rights reserved.
//


@interface TDMTunnelInfo : NSObject
@property (atomic,copy) NSString * userId;
@property (atomic,copy) NSString * appVersion;
@property (atomic,copy) NSString * channel;

@end
