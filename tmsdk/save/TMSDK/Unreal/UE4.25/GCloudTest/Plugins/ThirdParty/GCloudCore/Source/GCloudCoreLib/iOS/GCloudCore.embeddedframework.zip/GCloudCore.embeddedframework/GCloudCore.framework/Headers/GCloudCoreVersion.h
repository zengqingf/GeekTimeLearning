#ifndef GCLOUDCORE_VERSION__H
#define GCLOUDCORE_VERSION__H

#define GCLOUDCORE_VERSION_S "1.2.00.1039"
#define GCLOUDCORE_VERSION_HASH "abc4b4a1e699865363f429b3878da7b3c5cd810d"

const char *gcloudcore_get_version();
const char *gcloudcore_get_version_hash();

#endif
