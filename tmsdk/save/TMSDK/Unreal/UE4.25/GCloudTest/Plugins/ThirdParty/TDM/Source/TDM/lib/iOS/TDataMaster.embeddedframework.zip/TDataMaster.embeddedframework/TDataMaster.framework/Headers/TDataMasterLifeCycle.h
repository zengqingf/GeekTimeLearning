//
//  TDataMasterLifeCycle.h
//  TDataMaster
//
//  Created by lucasfan on 2019/1/11.
//  Copyright © 2019 TDataMaster. All rights reserved.
//

#ifndef TDataMasterLifeCycle_h
#define TDataMasterLifeCycle_h

class TDataMasterLifeCycle
{
public:
    static void registerLifeCycle();
};

#endif /* TDataMasterLifeCycle_h */
