//
//  tgpalite.h
//  tgpalite
//
//  Created by zohnzliu(刘专) on 2021/3/17.
//  Copyright © 2021 zohnzliu(刘专). All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for tgpalite.
FOUNDATION_EXPORT double tgpaliteVersionNumber;

//! Project version string for tgpalite.
FOUNDATION_EXPORT const unsigned char tgpaliteVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <tgpalite/PublicHeader.h>
#import "TGPAManager.h"


