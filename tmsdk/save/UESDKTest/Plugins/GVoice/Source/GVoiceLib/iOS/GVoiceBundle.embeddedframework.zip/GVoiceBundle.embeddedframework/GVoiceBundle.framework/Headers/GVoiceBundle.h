//
//  GVoiceBundle.h
//  GVoiceBundle
//
//  Created by Lilac on 2020/9/3.
//  Copyright © 2020 gvoice. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for GVoiceBundle.
FOUNDATION_EXPORT double GVoiceBundleVersionNumber;

//! Project version string for GVoiceBundle.
FOUNDATION_EXPORT const unsigned char GVoiceBundleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GVoiceBundle/PublicHeader.h>


